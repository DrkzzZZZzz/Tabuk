/// Model class for a place to visit during a trip
class PlaceVisit {
  final String place;
  final DateTime date;

  const PlaceVisit({required this.place, required this.date});
}
