// Trip model for Firestore
class Trip {
  final String id;
  String name;
  String location;
  DateTime startDate;
  DateTime endDate;
  String transportation;
  List<String> spots;
  final String status;
  final String userId;

  Trip({
    required this.id,
    required this.name,
    required this.location,
    required this.startDate,
    required this.endDate,
    required this.transportation,
    required this.spots,
    required this.userId,
    this.status = 'Planning',
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'location': location,
    'startDate': startDate.toIso8601String(),
    'endDate': endDate.toIso8601String(),
    'transportation': transportation,
    'spots': spots,
    'userId': userId,
    'status': status,
  };

  factory Trip.fromMap(Map<String, dynamic> map) => Trip(
    id: map['id'],
    name: map['name'],
    location: map['location'],
    startDate: DateTime.parse(map['startDate']),
    endDate: DateTime.parse(map['endDate']),
    transportation: map['transportation'],
    spots: List<String>.from(map['spots'] ?? []),
    userId: map['userId'] ?? '',
    status: map['status'] ?? 'Planning',
  );
}
