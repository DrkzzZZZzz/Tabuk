// ===========================================
// lib/models/hotspot.dart
// ===========================================

class Hotspot {
  final String hotspotId;
  final String name;
  final String description;
  final String category;
  final List<String> images;
  final List<String> transportation;
  final String operatingHours;
  final List<String> safetyTips;
  final double? entranceFee;
  final String contactInfo;
  final String localGuide;
  final bool restroom;
  final bool foodAccess;
  final List<String> suggestions;

  final DateTime createdAt;
  final double latitude;
  final double longitude;

  const Hotspot({
    required this.hotspotId,
    required this.name,
    required this.description,
    required this.category,
    required this.images,
    required this.transportation,
    required this.operatingHours,
    required this.safetyTips,
    this.entranceFee,
    required this.contactInfo,
    required this.localGuide,
    required this.restroom,
    required this.foodAccess,
    required this.suggestions,

    required this.createdAt,
    required this.latitude,
    required this.longitude,
  });

  // Factory constructor for creating Hotspot from JSON
  factory Hotspot.fromJson(Map<String, dynamic> json) {
    return Hotspot(
      hotspotId: json['hotspot_id'] ?? '',
      name: json['name'] ?? '',
      description: json['description'] ?? '',
      category: json['category'] ?? '',
      images: List<String>.from(json['images'] ?? []),
      transportation: List<String>.from(json['transportation'] ?? []),
      operatingHours: json['operating_hours'] ?? '',
      safetyTips: List<String>.from(json['safety_tips'] ?? []),
      entranceFee: json['entrance_fee']?.toDouble(),
      contactInfo: json['contact_info'] ?? '',
      localGuide: json['local_guide'] ?? '',
      restroom: json['restroom'] ?? false,
      foodAccess: json['food_access'] ?? false,
      suggestions: List<String>.from(json['suggestions'] ?? []),

      createdAt: DateTime.parse(
        json['created_at'] ?? DateTime.now().toIso8601String(),
      ),
      latitude: (json['latitude'] ?? 0.0).toDouble(),
      longitude: (json['longitude'] ?? 0.0).toDouble(),
    );
  }

  // Convert Hotspot to JSON
  Map<String, dynamic> toJson() {
    return {
      'hotspot_id': hotspotId,
      'name': name,
      'description': description,
      'category': category,
      'images': images,
      'transportation': transportation,
      'operating_hours': operatingHours,
      'safety_tips': safetyTips,
      'entrance_fee': entranceFee,
      'contact_info': contactInfo,
      'local_guide': localGuide,
      'restroom': restroom,
      'food_access': foodAccess,
      'suggestions': suggestions,

      'created_at': createdAt.toIso8601String(),
      'latitude': latitude,
      'longitude': longitude,
    };
  }

  // Copy with method for immutable updates
  Hotspot copyWith({
    String? hotspotId,
    String? name,
    String? description,
    String? category,
    List<String>? images,
    List<String>? transportation,
    String? operatingHours,
    List<String>? safetyTips,
    double? entranceFee,
    String? contactInfo,
    String? localGuide,
    bool? restroom,
    bool? foodAccess,
    List<String>? suggestions,

    DateTime? createdAt,
    double? latitude,
    double? longitude,
  }) {
    return Hotspot(
      hotspotId: hotspotId ?? this.hotspotId,
      name: name ?? this.name,
      description: description ?? this.description,
      category: category ?? this.category,
      images: images ?? this.images,
      transportation: transportation ?? this.transportation,
      operatingHours: operatingHours ?? this.operatingHours,
      safetyTips: safetyTips ?? this.safetyTips,
      entranceFee: entranceFee ?? this.entranceFee,
      contactInfo: contactInfo ?? this.contactInfo,
      localGuide: localGuide ?? this.localGuide,
      restroom: restroom ?? this.restroom,
      foodAccess: foodAccess ?? this.foodAccess,
      suggestions: suggestions ?? this.suggestions,

      createdAt: createdAt ?? this.createdAt,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
    );
  }

  @override
  String toString() {
    return 'Hotspot{hotspotId: $hotspotId, name: $name, category: $category, lat: $latitude, lng: $longitude}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is Hotspot && other.hotspotId == hotspotId;
  }

  @override
  int get hashCode => hotspotId.hashCode;

  // Helper methods
  bool get isFree => entranceFee == null || entranceFee == 0;

  bool get hasAmenities => restroom || foodAccess;

  String get formattedEntranceFee {
    if (isFree) return 'Free';
    return '₱${entranceFee!.toStringAsFixed(2)}';
  }
}
