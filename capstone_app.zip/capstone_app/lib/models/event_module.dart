import 'package:cloud_firestore/cloud_firestore.dart';

class Event {
  final String eventId;
  final String title;
  final String description;
  final String location;
  final DateTime date;
  final String postedBy;
  final DateTime createdAt;
  final String status;

  Event({
    required this.eventId,
    required this.title,
    required this.description,
    required this.location,
    required this.date,
    required this.postedBy,
    required this.createdAt,
    required this.status,
  });

  factory Event.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return Event(
      eventId: doc.id,
      title: data['title'] ?? '',
      description: data['description'] ?? '',
      location: data['location'] ?? '',
      date: (data['date'] as Timestamp).toDate(),
      postedBy: data['posted_by'] ?? '',
      createdAt: (data['created_at'] as Timestamp).toDate(),
      status: data['status'] ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'description': description,
      'location': location,
      'date': Timestamp.fromDate(date),
      'posted_by': postedBy,
      'created_at': Timestamp.fromDate(createdAt),
      'status': status,
    };
  }

  static Future<void> addEvent(Event event) async {
    await FirebaseFirestore.instance.collection('events').add(event.toMap());
  }

  static Stream<List<Event>> getEventsForMonth(DateTime month) {
    final start = DateTime(month.year, month.month, 1);
    final end = DateTime(month.year, month.month + 1, 0, 23, 59, 59);
    return FirebaseFirestore.instance
        .collection('events')
        .where('date', isGreaterThanOrEqualTo: Timestamp.fromDate(start))
        .where('date', isLessThanOrEqualTo: Timestamp.fromDate(end))
        .snapshots()
        .map(
          (snapshot) =>
              snapshot.docs.map((doc) => Event.fromFirestore(doc)).toList(),
        );
  }
}
