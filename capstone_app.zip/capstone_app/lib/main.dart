import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart'; // Add this import
import 'dart:async';
import 'screens/splash_screen.dart';
import 'services/connectivity_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Fix: Add the options parameter
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  runApp(const TabukRoot());
}

class TabukRoot extends StatefulWidget {
  const TabukRoot({super.key});

  @override
  State<TabukRoot> createState() => _TabukRootState();
}

class _TabukRootState extends State<TabukRoot> with WidgetsBindingObserver {
  late StreamSubscription<ConnectivityInfo> _connectivitySubscription;
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();
  final ConnectivityService _connectivityService = ConnectivityService();
  bool _isAppInForeground = true;
  String? _currentRouteName;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeConnectivityMonitoring();
  }

  void _initializeConnectivityMonitoring() {
    // Listen to connectivity changes
    _connectivitySubscription = _connectivityService.connectivityStream.listen(
      (ConnectivityInfo info) {
        _handleGlobalConnectivityChange(info);
      },
      onError: (error) {
        debugPrint('Global connectivity stream error: $error');
      },
    );

    // Start monitoring
    _connectivityService.startMonitoring();
  }

  void _handleGlobalConnectivityChange(ConnectivityInfo info) {
    debugPrint(
      'Connectivity status: ${info.status}, route: $_currentRouteName',
    );
    // Only handle global navigation if we're NOT on the splash screen
    // Let splash screen handle its own connectivity logic
    setState(() {}); // Force UI update for debugging
    if (_currentRouteName != null &&
        _currentRouteName != '/' &&
        _currentRouteName != '/splash') {
      if (info.status != ConnectionStatus.connected &&
          info.status != ConnectionStatus.checking) {
        _navigateToSplashScreen('Connection lost: ${info.message}');
      }
    }
  }

  void _navigateToSplashScreen(String reason) {
    if (_isAppInForeground && _navigatorKey.currentState != null) {
      debugPrint('Global navigation to splash screen: $reason');

      _navigatorKey.currentState?.pushAndRemoveUntil(
        MaterialPageRoute(
          builder: (_) => const SplashScreen(),
          settings: const RouteSettings(name: '/splash'),
        ),
        (route) => false,
      );
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);

    _isAppInForeground = state == AppLifecycleState.resumed;

    if (state == AppLifecycleState.resumed) {
      // App came to foreground - trigger connectivity check
      _connectivityService.checkConnection();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _connectivitySubscription.cancel();
    _connectivityService.stopMonitoring();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: _navigatorKey,
      title: 'Tabuk',
      theme: ThemeData(primarySwatch: Colors.orange, fontFamily: 'Roboto'),
      home: const SplashScreen(),
      routes: {'/splash': (context) => const SplashScreen()},
      onGenerateRoute: (settings) {
        _currentRouteName = settings.name;
        return null; // Let the default routing handle it
      },
      debugShowCheckedModeBanner: false,
    );
  }
}
