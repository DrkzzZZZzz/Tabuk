// ===========================================
// lib/services/connectivity_service.dart
// ===========================================

import 'package:flutter/foundation.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'dart:async';
import 'dart:io';
// Only import dart:html if on web
// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;

enum ConnectionStatus {
  checking,
  connected,
  noNetwork,
  noInternet,
  mobileDataNoInternet,
}

class ConnectivityInfo {
  final ConnectionStatus status;
  final ConnectivityResult? connectionType;
  final String message;
  final bool isMobileDataWithoutInternet;

  const ConnectivityInfo({
    required this.status,
    this.connectionType,
    required this.message,
    this.isMobileDataWithoutInternet = false,
  });
}

class ConnectivityService {
  static final ConnectivityService _instance = ConnectivityService._internal();
  factory ConnectivityService() => _instance;
  ConnectivityService._internal();

  StreamSubscription<List<ConnectivityResult>>? _connectivitySubscription;
  final StreamController<ConnectivityInfo> _connectivityController =
      StreamController<ConnectivityInfo>.broadcast();

  Stream<ConnectivityInfo> get connectivityStream =>
      _connectivityController.stream;

  static const List<String> _testUrls = [
    'google.com',
    '8.8.8.8',
    'cloudflare.com',
    '1.1.1.1',
    'facebook.com',
  ];

  void startMonitoring() {
    // Initial check
    checkConnection();

    // Listen to connectivity changes
    _connectivitySubscription = Connectivity().onConnectivityChanged.listen((
      List<ConnectivityResult> results,
    ) {
      checkConnection();
    });
  }

  void stopMonitoring() {
    _connectivitySubscription?.cancel();
    _connectivitySubscription = null;
  }

  Future<ConnectivityInfo> checkConnection() async {
    _emitStatus(
      ConnectivityInfo(
        status: ConnectionStatus.checking,
        message: 'Checking connection...',
      ),
    );

    try {
      if (kIsWeb) {
        // Web: use browser's online status
        final online = html.window.navigator.onLine ?? false;
        final info = ConnectivityInfo(
          status:
              online ? ConnectionStatus.connected : ConnectionStatus.noInternet,
          connectionType:
              online ? ConnectivityResult.wifi : ConnectivityResult.none,
          message: online ? 'Connected to internet' : 'No internet connection',
        );
        _emitStatus(info);
        return info;
      }

      final connectivityResult = await Connectivity().checkConnectivity();

      // Check if device has any network connection
      if (connectivityResult.contains(ConnectivityResult.none) ||
          connectivityResult.isEmpty) {
        final info = ConnectivityInfo(
          status: ConnectionStatus.noNetwork,
          connectionType: ConnectivityResult.none,
          message: 'No network connection',
        );
        _emitStatus(info);
        return info;
      }

      final connectionType = connectivityResult.first;

      // Test actual internet connectivity
      final hasRealInternet = await _testInternetAccess(connectionType);

      ConnectivityInfo info;
      if (hasRealInternet) {
        info = ConnectivityInfo(
          status: ConnectionStatus.connected,
          connectionType: connectionType,
          message: 'Connected to internet',
        );
      } else {
        // Determine specific no-internet scenario
        if (connectivityResult.contains(ConnectivityResult.mobile)) {
          info = ConnectivityInfo(
            status: ConnectionStatus.mobileDataNoInternet,
            connectionType: connectionType,
            message: 'Mobile data enabled but no internet access',
            isMobileDataWithoutInternet: true,
          );
        } else if (connectivityResult.contains(ConnectivityResult.wifi)) {
          info = ConnectivityInfo(
            status: ConnectionStatus.noInternet,
            connectionType: connectionType,
            message: 'Connected to WiFi but no internet access',
          );
        } else {
          info = ConnectivityInfo(
            status: ConnectionStatus.noInternet,
            connectionType: connectionType,
            message: 'Connected to network but no internet access',
          );
        }
      }

      _emitStatus(info);
      return info;
    } catch (e) {
      final info = ConnectivityInfo(
        status: ConnectionStatus.noInternet,
        message: 'Connection error',
      );
      _emitStatus(info);
      return info;
    }
  }

  Future<bool> _testInternetAccess(ConnectivityResult connectionType) async {
    try {
      // Try multiple attempts for mobile data reliability
      for (int attempt = 0; attempt < 2; attempt++) {
        for (String url in _testUrls) {
          try {
            final result = await InternetAddress.lookup(
              url,
            ).timeout(const Duration(seconds: 8));

            if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
              // Double-check with HTTP request for mobile data
              if (connectionType == ConnectivityResult.mobile) {
                return await _testHttpConnection();
              }
              return true;
            }
          } catch (e) {
            continue; // Try next URL
          }
        }
        // Wait before retry
        if (attempt == 0) {
          await Future.delayed(const Duration(seconds: 2));
        }
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  Future<bool> _testHttpConnection() async {
    try {
      final httpClient = HttpClient();
      httpClient.connectionTimeout = const Duration(seconds: 10);

      final request = await httpClient.getUrl(
        Uri.parse('https://www.google.com'),
      );
      final response = await request.close().timeout(
        const Duration(seconds: 10),
      );

      httpClient.close();
      return response.statusCode == 200;
    } catch (e) {
      return false;
    }
  }

  void _emitStatus(ConnectivityInfo info) {
    if (!_connectivityController.isClosed) {
      _connectivityController.add(info);
    }
  }

  void dispose() {
    stopMonitoring();
    _connectivityController.close();
  }
}
