import 'package:flutter/foundation.dart';
// Only import dart:html if on web
// ignore: avoid_web_libraries_in_flutter
import 'dart:html' as html;
import 'package:connectivity_plus/connectivity_plus.dart';

class WebConnectivityService {
  static Future<bool> isOnline() async {
    if (kIsWeb) {
      // Web: use browser's online status
      return html.window.navigator.onLine ?? false;
    } else {
      // Android/iOS/other: use connectivity_plus
      final connectivityResult = await Connectivity().checkConnectivity();
      return !connectivityResult.contains(ConnectivityResult.none);
    }
  }
}
