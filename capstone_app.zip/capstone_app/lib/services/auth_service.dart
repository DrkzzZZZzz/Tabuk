import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AuthService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;
  static const String _emailKey = 'pending_email';

  // Get current user
  static User? get currentUser => _auth.currentUser;

  // Auth state stream
  static Stream<User?> get authStateChanges => _auth.authStateChanges();

  // Email/Password Sign Up
  static Future<UserCredential?> signUpWithEmailPassword({
    required String email,
    required String password,
    required String role,
  }) async {
    try {
      UserCredential userCredential = await _auth
          .createUserWithEmailAndPassword(email: email, password: password);

      // Send email verification
      await userCredential.user?.sendEmailVerification();

      // Store additional user data (like role) in Firestore
      if (userCredential.user != null) {
        await AuthService.storeUserData(userCredential.user!.uid, email, role);
      }

      return userCredential;
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    } catch (e) {
      throw 'An unexpected error occurred: ${e.toString()}';
    }
  }

  // Email/Password Sign In
  static Future<UserCredential?> signInWithEmailPassword({
    required String email,
    required String password,
  }) async {
    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return userCredential;
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    } catch (e) {
      throw 'An unexpected error occurred: ${e.toString()}';
    }
  }

  // Send Email Link for Sign In
  static Future<void> sendSignInLinkToEmail({
    required String email,
    String? url,
    String? androidPackageName,
    String? iOSBundleId,
  }) async {
    try {
      // Store email locally for later use
      await _storeEmailLocally(email);

      final actionCodeSettings = ActionCodeSettings(
        url: url ?? 'https://tabuk-ce16e.firebaseapp.com/__/auth/action',
        handleCodeInApp: true,
        androidPackageName: androidPackageName,
        androidInstallApp: true,
        androidMinimumVersion: '12',
        iOSBundleId: iOSBundleId,
      );

      await _auth.sendSignInLinkToEmail(
        email: email,
        actionCodeSettings: actionCodeSettings,
      );
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    } catch (e) {
      throw 'Failed to send email link: \\${e.toString()}';
    }
  }

  // Complete Sign In with Email Link
  static Future<UserCredential?> signInWithEmailLink({
    required String email,
    required String emailLink,
  }) async {
    try {
      if (_auth.isSignInWithEmailLink(emailLink)) {
        UserCredential userCredential = await _auth.signInWithEmailLink(
          email: email,
          emailLink: emailLink,
        );

        // Clear stored email after successful sign in
        await _clearStoredEmail();

        return userCredential;
      } else {
        throw 'Invalid email link';
      }
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    } catch (e) {
      throw 'Failed to sign in with email link: ${e.toString()}';
    }
  }

  // Check if link is a sign-in with email link
  static bool isSignInWithEmailLink(String emailLink) {
    return _auth.isSignInWithEmailLink(emailLink);
  }

  // Get stored email (for completing email link sign in)
  static Future<String?> getStoredEmail() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      return prefs.getString(_emailKey);
    } catch (e) {
      debugPrint('Error getting stored email: $e');
      return null;
    }
  }

  // Store email locally
  static Future<void> _storeEmailLocally(String email) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_emailKey, email);
    } catch (e) {
      debugPrint('Error storing email: $e');
    }
  }

  // Clear stored email
  static Future<void> _clearStoredEmail() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_emailKey);
    } catch (e) {
      debugPrint('Error clearing stored email: $e');
    }
  }

  // Password Reset
  static Future<void> sendPasswordResetEmail(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email);
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    } catch (e) {
      throw 'Failed to send password reset email: ${e.toString()}';
    }
  }

  // Sign Out
  static Future<void> signOut() async {
    try {
      await _auth.signOut();
      await _clearStoredEmail();
    } catch (e) {
      throw 'Failed to sign out: ${e.toString()}';
    }
  }

  // Delete User Account
  static Future<void> deleteUser() async {
    try {
      await currentUser?.delete();
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    } catch (e) {
      throw 'Failed to delete account: ${e.toString()}';
    }
  }

  // Reload user data
  static Future<void> reloadUser() async {
    try {
      await currentUser?.reload();
    } catch (e) {
      debugPrint('Error reloading user: $e');
    }
  }

  // Check if email is verified
  static bool get isEmailVerified => currentUser?.emailVerified ?? false;

  // Send email verification (no Dynamic Links, just default or custom HTTPS link)
  static Future<void> sendEmailVerification({String? url}) async {
    try {
      if (url != null) {
        await currentUser?.sendEmailVerification(
          ActionCodeSettings(
            url: url,
            handleCodeInApp: true,
            androidInstallApp: true,
            androidMinimumVersion: '12',
          ),
        );
      } else {
        await currentUser?.sendEmailVerification();
      }
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    } catch (e) {
      throw 'Failed to send verification email: \\${e.toString()}';
    }
  }

  // Link email/password credential to existing account
  static Future<UserCredential?> linkWithEmailPassword({
    required String email,
    required String password,
  }) async {
    try {
      final credential = EmailAuthProvider.credential(
        email: email,
        password: password,
      );
      return await currentUser?.linkWithCredential(credential);
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    } catch (e) {
      throw 'Failed to link credential: ${e.toString()}';
    }
  }

  // Link email link credential to existing account
  static Future<UserCredential?> linkWithEmailLink({
    required String email,
    required String emailLink,
  }) async {
    try {
      final credential = EmailAuthProvider.credentialWithLink(
        email: email,
        emailLink: emailLink,
      );
      return await currentUser?.linkWithCredential(credential);
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    } catch (e) {
      throw 'Failed to link email link credential: ${e.toString()}';
    }
  }

  // Re-authenticate with email/password
  static Future<UserCredential?> reauthenticateWithEmailPassword({
    required String email,
    required String password,
  }) async {
    try {
      final credential = EmailAuthProvider.credential(
        email: email,
        password: password,
      );
      return await currentUser?.reauthenticateWithCredential(credential);
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    } catch (e) {
      throw 'Failed to re-authenticate: ${e.toString()}';
    }
  }

  // Re-authenticate with email link
  static Future<UserCredential?> reauthenticateWithEmailLink({
    required String email,
    required String emailLink,
  }) async {
    try {
      final credential = EmailAuthProvider.credentialWithLink(
        email: email,
        emailLink: emailLink,
      );
      return await currentUser?.reauthenticateWithCredential(credential);
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    } catch (e) {
      throw 'Failed to re-authenticate with email link: ${e.toString()}';
    }
  }

  // Handle Firebase Auth Exceptions
  static String _handleAuthException(FirebaseAuthException e) {
    switch (e.code) {
      case 'weak-password':
        return 'The password provided is too weak.';
      case 'email-already-in-use':
        return 'An account already exists for this email address.';
      case 'invalid-email':
        return 'The email address is not valid.';
      case 'user-disabled':
        return 'This user account has been disabled.';
      case 'user-not-found':
        return 'No user found for this email address.';
      case 'wrong-password':
        return 'Wrong password provided.';
      case 'invalid-credential':
        return 'The provided credentials are invalid.';
      case 'account-exists-with-different-credential':
        return 'An account already exists with a different sign-in method.';
      case 'credential-already-in-use':
        return 'This credential is already associated with a different user account.';
      case 'operation-not-allowed':
        return 'This sign-in method is not enabled for your Firebase project.';
      case 'too-many-requests':
        // Firebase does not provide the retry-after seconds in the error, so we show a generic suggestion
        return 'Too many requests. Please try again in 60 seconds.';
      case 'network-request-failed':
        return 'Network error. Please check your internet connection.';
      case 'requires-recent-login':
        return 'This operation requires recent authentication. Please sign in again.';
      default:
        return e.message ?? 'An authentication error occurred.';
    }
  }

  static Future<UserCredential?> signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();
      if (googleUser == null) return null; // User canceled

      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      final credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final userCredential = await _auth.signInWithCredential(credential);

      // If the user's email is not verified, send verification with custom URL
      if (userCredential.user != null &&
          !(userCredential.user!.emailVerified)) {
        await userCredential.user!.sendEmailVerification(
          ActionCodeSettings(
            url: 'https://tabuk-ce16e.firebaseapp.com/__/auth/action',
            handleCodeInApp: true,
            androidPackageName: null,
            androidInstallApp: true,
            androidMinimumVersion: '12',
            iOSBundleId: null,
          ),
        );
      }

      return userCredential;
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    } catch (e) {
      throw 'Google sign-in failed: ${e.toString()}';
    }
  }

  // Anonymous Sign In (Guest Account)
  static Future<UserCredential?> signInAnonymously({
    String role = 'Guest',
  }) async {
    try {
      UserCredential userCredential = await _auth.signInAnonymously();
      // Store guest user data in Firestore
      if (userCredential.user != null) {
        await AuthService.storeUserData(userCredential.user!.uid, '', role);
      }
      return userCredential;
    } on FirebaseAuthException catch (e) {
      throw _handleAuthException(e);
    } catch (e) {
      throw 'An unexpected error occurred: ${e.toString()}';
    }
  }

  // Store user data in Firestore
  static Future<void> storeUserData(
    String uid,
    String email,
    String role, {
    String? name,
    String? phone,
  }) async {
    try {
      await FirebaseFirestore.instance.collection('users').doc(uid).set({
        'email': email,
        'role': role,
        'name': name,
        'phone': phone,
        'created_at': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (e) {
      debugPrint('Error storing user data: $e');
    }
  }

  // Get user data from Firestore
  static Future<Map<String, dynamic>?> getUserData(String uid) async {
    try {
      DocumentSnapshot doc =
          await FirebaseFirestore.instance.collection('users').doc(uid).get();
      return doc.data() as Map<String, dynamic>?;
    } catch (e) {
      debugPrint('Error getting user data: $e');
      return null;
    }
  }

  // Update user data in Firestore
  static Future<void> updateUserData(
    String uid, {
    String? email,
    String? role,
    String? name,
    String? phone,
  }) async {
    try {
      await FirebaseFirestore.instance.collection('users').doc(uid).set({
        'email': email,
        'role': role,
        'name': name,
        'phone': phone,
        'updated_at': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
    } catch (e) {
      debugPrint('Error updating user data: $e');
    }
  }

  // Delete user data from Firestore
  static Future<void> deleteUserData(String uid) async {
    try {
      await FirebaseFirestore.instance.collection('users').doc(uid).delete();
    } catch (e) {
      debugPrint('Error deleting user data: $e');
    }
  }

  // Log unhandled errors
  static void logError(dynamic error, StackTrace stackTrace) {
    // Implement your error logging here (e.g., send to Sentry, Firebase Crashlytics, etc.)
    if (kDebugMode) {
      print('Unhandled error: $error');
    }
    if (kDebugMode) {
      print('Stack trace: $stackTrace');
    }
  }
}
