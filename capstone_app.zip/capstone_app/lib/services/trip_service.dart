import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/trip_model.dart';

class TripService {
  static Future<void> saveTrip(Trip trip) async {
    await FirebaseFirestore.instance
        .collection('trip_planning')
        .doc(trip.id)
        .set(trip.toMap());
  }

  static Future<List<Trip>> getTrips(String userId) async {
    final snapshot =
        await FirebaseFirestore.instance
            .collection('trip_planning')
            .where('userId', isEqualTo: userId)
            .get();
    return snapshot.docs.map((doc) => Trip.fromMap(doc.data())).toList();
  }

  static Future<void> deleteTrip(String tripId) async {
    await FirebaseFirestore.instance
        .collection('trip_planning')
        .doc(tripId)
        .delete();
  }
}
