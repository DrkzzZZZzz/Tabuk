import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/hotspots_model.dart';

class HotspotService {
  static final _collection = FirebaseFirestore.instance.collection('hotspots');

  static Future<void> addHotspot(Hotspot hotspot) async {
    await _collection.doc(hotspot.hotspotId).set(hotspot.toJson());
  }

  static Future<void> updateHotspot(Hotspot hotspot) async {
    await _collection.doc(hotspot.hotspotId).update(hotspot.toJson());
  }

  static Future<void> deleteHotspot(String hotspotId) async {
    await _collection.doc(hotspotId).delete();
  }

  static Stream<List<Hotspot>> getHotspotsStream() {
    return _collection.snapshots().map(
      (snapshot) =>
          snapshot.docs.map((doc) => Hotspot.fromJson(doc.data())).toList(),
    );
  }
}
