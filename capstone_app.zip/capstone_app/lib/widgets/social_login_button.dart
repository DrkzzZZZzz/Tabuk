// ===========================================
// lib/widgets/social_login_button.dart
// ===========================================

import 'package:flutter/material.dart';

class SocialLoginButton extends StatelessWidget {
  final String text;
  final IconData? icon;
  final String? imagePath;
  final Color backgroundColor;
  final Color textColor;
  final VoidCallback onPressed;

  const SocialLoginButton({
    super.key,
    required this.text,
    this.icon,
    this.imagePath,
    required this.backgroundColor,
    required this.textColor,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 45,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: backgroundColor,
          foregroundColor: textColor,
          elevation: 2,
          // ignore: deprecated_member_use
          shadowColor: Colors.black.withOpacity(0.1),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
            side:
                backgroundColor == Colors.white
                    // ignore: deprecated_member_use
                    ? BorderSide(color: Colors.grey.withOpacity(0.3))
                    : BorderSide.none,
          ),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Show image if imagePath is provided, otherwise show icon
            if (imagePath != null)
              Image.asset(
                imagePath!,
                width: 20,
                height: 20,
                errorBuilder: (context, error, stackTrace) {
                  // Fallback to icon if image fails to load
                  return Icon(icon ?? Icons.login, size: 20, color: textColor);
                },
              )
            else if (icon != null)
              Icon(icon, size: 20, color: textColor),
            const SizedBox(width: 12),
            Text(
              text,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w500,
                color: textColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
