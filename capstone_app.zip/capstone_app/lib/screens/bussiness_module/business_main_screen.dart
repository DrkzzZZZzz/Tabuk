import 'package:flutter/material.dart';
import 'package:capstone_app/utils/colors.dart';

/// Main screen for business owner users with bottom navigation.
class MainBusinessOwnerScreen extends StatefulWidget {
  const MainBusinessOwnerScreen({super.key});

  @override
  State<MainBusinessOwnerScreen> createState() =>
      _MainBusinessOwnerScreenState();
}

class _MainBusinessOwnerScreenState extends State<MainBusinessOwnerScreen> {
  int _selectedIndex = 0;

  // List of screens for navigation - matching the bottom nav items
  final List<Widget> _screens = [
    const _PlaceholderScreen(title: 'My Business'),
    const _PlaceholderScreen(title: 'Listings'),
    const _PlaceholderScreen(title: 'Analytics'),
    const _PlaceholderScreen(title: 'Reviews'),
    const _PlaceholderScreen(title: 'Profile'),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: _buildBottomNavBar(),
    );
  }

  Widget _buildBottomNavBar() {
    return BottomNavigationBar(
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.business),
          label: 'My Business',
        ),
        BottomNavigationBarItem(icon: Icon(Icons.list_alt), label: 'Listings'),
        BottomNavigationBarItem(
          icon: Icon(Icons.analytics),
          label: 'Analytics',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.rate_review),
          label: 'Reviews',
        ),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
      ],
      currentIndex: _selectedIndex,
      selectedItemColor: AppColors.primaryOrange,
      unselectedItemColor: AppColors.textLight,
      onTap: _onItemTapped,
      type: BottomNavigationBarType.fixed,
      showSelectedLabels: true,
      showUnselectedLabels: true,
    );
  }
}

// Helper widget for placeholder screens
class _PlaceholderScreen extends StatelessWidget {
  final String title;

  const _PlaceholderScreen({required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        backgroundColor: AppColors.primaryOrange,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.construction, size: 64, color: AppColors.textLight),
            const SizedBox(height: 16),
            Text(
              '$title Screen',
              style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              'Coming Soon',
              style: TextStyle(fontSize: 16, color: AppColors.textLight),
            ),
          ],
        ),
      ),
    );
  }
}
