// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';
import '../../../models/event_module.dart';
import '../../../utils/constants.dart';
import '../../../utils/colors.dart';

class EventCalendarScreen extends StatefulWidget {
  const EventCalendarScreen({super.key});

  @override
  State<EventCalendarScreen> createState() => _EventCalendarScreenState();
}

class _EventCalendarScreenState extends State<EventCalendarScreen> {
  DateTime _focusedDay = DateTime.now();
  DateTime? _selectedDay;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(AppConstants.events),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none),
            onPressed: () {},
          ),
        ],
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Image.asset(
              'assets/images/TABUK-new-logo.png',
              width: double.infinity,
              height: 150,
              fit: BoxFit.cover,
            ),
            const SizedBox(height: 16),
            const Text(
              AppConstants.eventCalendarTitle,
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: AppColors.textDark,
              ),
            ),
            const SizedBox(height: 16),
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: TableCalendar<Event>(
                  rowHeight: 44,
                  firstDay: DateTime.utc(2020, 1, 1),
                  lastDay: DateTime.utc(2100, 12, 31),
                  focusedDay: _focusedDay,
                  selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
                  onDaySelected: (selectedDay, focusedDay) {
                    setState(() {
                      _selectedDay = selectedDay;
                      _focusedDay = focusedDay;
                    });
                  },
                  calendarFormat: CalendarFormat.month,
                  headerStyle: const HeaderStyle(
                    formatButtonVisible: false,
                    titleCentered: true,
                    titleTextStyle: TextStyle(
                      color: AppColors.primaryTeal,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  calendarStyle: CalendarStyle(
                    todayDecoration: BoxDecoration(
                      color: AppColors.primaryOrange.withOpacity(0.5),
                      shape: BoxShape.circle,
                    ),
                    selectedDecoration: const BoxDecoration(
                      color: AppColors.primaryTeal,
                      shape: BoxShape.circle,
                    ),
                    markerDecoration: const BoxDecoration(
                      color: AppColors.primaryOrange,
                      shape: BoxShape.circle,
                    ),
                    cellMargin: EdgeInsets.zero,
                    defaultTextStyle: const TextStyle(
                      fontSize: 12,
                      color: AppColors.textDark,
                    ),
                    weekendTextStyle: const TextStyle(
                      fontSize: 12,
                      color: AppColors.primaryOrange,
                    ),
                    outsideTextStyle: const TextStyle(
                      fontSize: 12,
                      color: AppColors.textLight,
                    ),
                  ),
                  daysOfWeekStyle: const DaysOfWeekStyle(
                    weekdayStyle: TextStyle(
                      fontSize: 11,
                      color: AppColors.textLight,
                    ),
                    weekendStyle: TextStyle(
                      fontSize: 11,
                      color: AppColors.primaryOrange,
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                TextButton(
                  onPressed: () {
                    setState(() {
                      _focusedDay = DateTime(
                        _focusedDay.year,
                        _focusedDay.month - 1,
                        1,
                      );
                    });
                  },
                  child: const Text(
                    AppConstants.thisMonth,
                    style: TextStyle(color: AppColors.primaryTeal),
                  ),
                ),
                TextButton(
                  onPressed: () {
                    setState(() {
                      _focusedDay = DateTime(
                        _focusedDay.year,
                        _focusedDay.month + 1,
                        1,
                      );
                    });
                  },
                  child: const Text(
                    AppConstants.nextMonth,
                    style: TextStyle(color: AppColors.primaryTeal),
                  ),
                ),
              ],
            ),
            // Example: show events for selected day or focused day
            ..._getEventsForDay(_selectedDay ?? _focusedDay).map(
              (event) => Card(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: ListTile(
                  leading: const Icon(
                    Icons.event,
                    color: AppColors.primaryTeal,
                  ),
                  title: Text(
                    event.title,
                    style: const TextStyle(color: AppColors.textDark),
                  ),
                  subtitle: Text(
                    '${_formatDate(event.date)}\n${event.location}',
                    style: const TextStyle(color: AppColors.textLight),
                  ),
                  onTap: () => _showEventDetailsForDay([event]),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Event> _getEventsForDay(DateTime day) {
    // Placeholder: you should implement your own logic to get events for the given day
    return [];
  }

  String _formatDate(DateTime date) {
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    return '${months[date.month - 1]} ${date.day}, ${date.year}';
  }

  void _showEventDetailsForDay(List<Event> events) {
    // Show a simple dialog with event details
    if (events.isEmpty) return;
    final event = events.first;
    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Text(
              event.title,
              style: const TextStyle(color: AppColors.primaryTeal),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _formatDate(event.date),
                  style: const TextStyle(color: AppColors.textLight),
                ),
                const SizedBox(height: 8),
                Text(
                  event.location,
                  style: const TextStyle(color: AppColors.textDark),
                ),
                const SizedBox(height: 8),
                Text(
                  event.description,
                  style: const TextStyle(color: AppColors.textLight),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text(
                  'Close',
                  style: TextStyle(color: AppColors.primaryTeal),
                ),
              ),
            ],
          ),
    );
  }
}

extension DateTimeMonthName on DateTime {
  String monthName() {
    const months = [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December',
    ];
    return months[month - 1];
  }
}
