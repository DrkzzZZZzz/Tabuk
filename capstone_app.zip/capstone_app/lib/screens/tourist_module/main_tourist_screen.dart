import 'package:flutter/material.dart';
import 'event_calendar/event_calendar.dart';
import 'home/home.dart';
import 'map/map_screen.dart';
import 'trips/trips_screen.dart';
import 'profile/profile_screen.dart';
import 'package:capstone_app/utils/colors.dart';

/// Main screen for tourist users with bottom navigation.
class MainTouristScreen extends StatefulWidget {
  const MainTouristScreen({super.key});

  @override
  State<MainTouristScreen> createState() => _MainTouristScreenState();
}

class _MainTouristScreenState extends State<MainTouristScreen> {
  int _selectedIndex = 0;

  // List of screens for navigation
  final List<Widget> _screens = [
    const HomeScreen(),
    const MapScreen(),
    const TripsScreen(),
    const EventCalendarScreen(),
    const ProfileScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: _buildBottomNavBar(),
    );
  }

  Widget _buildBottomNavBar() {
    return BottomNavigationBar(
      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
        BottomNavigationBarItem(icon: Icon(Icons.map), label: 'Maps'),
        BottomNavigationBarItem(icon: Icon(Icons.luggage), label: 'Trips'),
        BottomNavigationBarItem(
          icon: Icon(Icons.calendar_today),
          label: 'Calendar',
        ),
        BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
      ],
      currentIndex: _selectedIndex,
      selectedItemColor: AppColors.primaryOrange,
      unselectedItemColor: AppColors.textLight,
      onTap: _onItemTapped,
      type: BottomNavigationBarType.fixed,
      showSelectedLabels: true,
      showUnselectedLabels: true,
    );
  }
}
