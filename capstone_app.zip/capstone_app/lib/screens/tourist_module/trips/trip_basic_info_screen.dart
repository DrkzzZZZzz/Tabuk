// lib/screens/tourist_mdoule/trips/trip_basic_info_screen.dart

// ignore_for_file: depend_on_referenced_packages, deprecated_member_use, use_build_context_synchronously

import 'package:flutter/material.dart';

import 'package:intl/intl.dart';

import 'package:capstone_app/utils/colors.dart';
import 'package:capstone_app/utils/constants.dart';

import 'transportation_selection_screen.dart';

class TripBasicInfoScreen extends StatefulWidget {
  final String destination;

  const TripBasicInfoScreen({super.key, required this.destination});

  @override
  State<TripBasicInfoScreen> createState() => _TripBasicInfoScreenState();
}

class _TripBasicInfoScreenState extends State<TripBasicInfoScreen> {
  // Controllers
  final TextEditingController _tripNameController = TextEditingController();

  // Trip date state
  DateTime? _startDate;
  DateTime? _endDate;

  // Constants
  static const int _totalSteps = 3;
  static const int _currentStep = 1;

  @override
  void initState() {
    super.initState();
    // Initialize with default values
    _initializeDefaultValues();
  }

  void _initializeDefaultValues() {
    // Set default dates (tomorrow to 3 days from now)
    _startDate = DateTime.now().add(const Duration(days: 1));
    _endDate = DateTime.now().add(const Duration(days: 3));

    // Default trip name is the destination + year
    _tripNameController.text = '${widget.destination} ${DateTime.now().year}';
  }

  @override
  void dispose() {
    // Clean up controllers
    _tripNameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(),
      body: Column(
        children: [
          _buildProgressIndicator(),
          Expanded(child: _buildBasicInfoContent()),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.white,
      foregroundColor: Colors.black,
      elevation: 0,
      leading: IconButton(
        icon: const Icon(Icons.arrow_back),
        onPressed: () => Navigator.pop(context),
      ),
      title: Text(
        'Trip to ${widget.destination}',
        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
      ),
      centerTitle: true,
    );
  }

  Widget _buildProgressIndicator() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
      child: Row(
        children: List.generate(_totalSteps, (index) {
          return Expanded(
            child: Container(
              height: 6,
              margin: const EdgeInsets.symmetric(horizontal: 4),
              decoration: BoxDecoration(
                color:
                    index < _currentStep
                        ? AppColors.primaryOrange
                        : AppColors.textLight.withOpacity(0.2),
                borderRadius: BorderRadius.circular(3),
              ),
            ),
          );
        }),
      ),
    );
  }

  Widget _buildBasicInfoContent() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSectionHeader(),
            const SizedBox(height: 16),
            _buildTripNameField(),
            const SizedBox(height: 24),
            _buildTripDatesSection(),
            const SizedBox(height: 32),
            _buildNextButton(),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader() {
    return const Text(
      'Trip Details',
      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
    );
  }

  Widget _buildTripNameField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          AppConstants
              .signUp, // Use a relevant constant or add a new one for 'Trip Name'
          style: const TextStyle(color: AppColors.textLight),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _tripNameController,
          decoration: InputDecoration(
            hintText: 'Enter trip name',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(color: AppColors.primaryOrange),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: const BorderSide(
                color: AppColors.primaryOrange,
                width: 2,
              ),
            ),
          ),
          style: const TextStyle(fontSize: 16),
        ),
      ],
    );
  }

  Widget _buildTripDatesSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Trip Dates', style: TextStyle(color: AppColors.textLight)),
        const SizedBox(height: 8),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              SizedBox(width: 160, child: _buildDateField(isStartDate: true)),
              const SizedBox(width: 16),
              SizedBox(width: 160, child: _buildDateField(isStartDate: false)),
            ],
          ),
        ),
        const SizedBox(height: 8),
        if (_startDate != null && _endDate != null)
          Text(
            '${_calculateTripDuration()} days',
            style: const TextStyle(
              color: AppColors.primaryTeal,
              fontWeight: FontWeight.w500,
            ),
          ),
      ],
    );
  }

  Widget _buildDateField({required bool isStartDate}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          isStartDate ? 'Start Date' : 'End Date',
          style: const TextStyle(fontSize: 12),
        ),
        const SizedBox(height: 4),
        _buildDateSelector(isStartDate),
      ],
    );
  }

  Widget _buildDateSelector(bool isStartDate) {
    final date = isStartDate ? _startDate : _endDate;
    final formattedDate =
        date != null ? DateFormat('MMM dd, yyyy').format(date) : 'Select date';

    return GestureDetector(
      onTap: () => _selectDate(isStartDate),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.primaryOrange),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            Icon(
              Icons.calendar_today,
              size: 16,
              color: AppColors.primaryOrange,
            ),
            const SizedBox(width: 8),
            Flexible(
              child: Text(
                formattedDate,
                style: const TextStyle(fontSize: 14),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNextButton() {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: ElevatedButton(
        onPressed: _continueToTransportation,
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primaryOrange,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
        child: const Text(
          'Next',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  Future<void> _selectDate(bool isStartDate) async {
    final initialDate =
        isStartDate
            ? _startDate ?? DateTime.now()
            : _endDate ??
                (_startDate ?? DateTime.now()).add(const Duration(days: 1));
    final firstDate =
        isStartDate ? DateTime.now() : _startDate ?? DateTime.now();
    final lastDate = DateTime.now().add(const Duration(days: 365));
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: initialDate,
      firstDate: firstDate,
      lastDate: lastDate,
      builder: (context, child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: ColorScheme.light(primary: AppColors.primaryOrange),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() {
        if (isStartDate) {
          _startDate = picked;
          if (_endDate != null && _endDate!.isBefore(_startDate!)) {
            _endDate = _startDate!.add(const Duration(days: 1));
          }
        } else {
          _endDate = picked;
        }
      });
    }
  }

  int _calculateTripDuration() {
    if (_startDate == null || _endDate == null) return 0;
    return _endDate!.difference(_startDate!).inDays + 1;
  }

  void _continueToTransportation() {
    // Validate inputs
    if (!_validateInputs()) return;
    // Continue to transportation screen, and wait for result
    Navigator.push(
      context,
      MaterialPageRoute(
        builder:
            (context) => TransportationSelectionScreen(
              destination: widget.destination,
              tripName: _tripNameController.text,
              startDate: _startDate!,
              endDate: _endDate!,
            ),
      ),
    ).then((result) {
      if (result != null && result is Map<String, dynamic>) {
        Navigator.pop(context, result); // Pass result up to TripsScreen
      }
    });
  }

  bool _validateInputs() {
    // Validate that trip has a name
    if (_tripNameController.text.isEmpty) {
      _showValidationError('Please enter a trip name');
      return false;
    }

    // Validate that trip has dates
    if (_startDate == null || _endDate == null) {
      _showValidationError('Please select both start and end dates');
      return false;
    }

    return true;
  }

  void _showValidationError(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
