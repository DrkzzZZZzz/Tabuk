// lib/screens/tourist_module/trips/trips_screen.dart

// ignore_for_file: depend_on_referenced_packages, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';

import 'trip_basic_info_screen.dart';
import '../../../services/trip_service.dart';
import '../../../services/auth_service.dart';

import '../../../models/trip_model.dart' as firestoretrip;

class TripsScreen extends StatefulWidget {
  const TripsScreen({super.key});

  @override
  State<TripsScreen> createState() => _TripsScreenState();
}

class _TripsScreenState extends State<TripsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  late Stream<QuerySnapshot> _tripStream;
  String? _userId;

  String getUserId() {
    // Use AuthService to get the current user ID
    return AuthService.currentUser?.uid ?? '';
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(_handleTabChange);
    _userId = getUserId();
    _tripStream =
        FirebaseFirestore.instance
            .collection('trip_planning')
            .where('userId', isEqualTo: _userId)
            .snapshots();
  }

  void _handleTabChange() {
    if (!_tabController.indexIsChanging) {
      setState(() {});
    }
  }

  // Trip management methods
  Future<void> _addNewTrip(firestoretrip.Trip trip) async {
    // Ensure trip has a unique id and userId
    final newTrip = firestoretrip.Trip(
      id: trip.id.isNotEmpty ? trip.id : const Uuid().v4(),
      name: trip.name,
      location: trip.location,
      startDate: trip.startDate,
      endDate: trip.endDate,
      transportation: trip.transportation,
      spots: trip.spots,
      userId: _userId ?? '',
      status: trip.status,
    );
    await TripService.saveTrip(newTrip);
    _showSnackBar('Trip to ${trip.location} added successfully!', Colors.green);
  }

  Future<void> _archiveTrip(firestoretrip.Trip trip) async {
    final archivedTrip = firestoretrip.Trip(
      id: trip.id,
      name: trip.name,
      location: trip.location,
      startDate: trip.startDate,
      endDate: trip.endDate,
      transportation: trip.transportation,
      spots: trip.spots,
      userId: trip.userId,
      status: 'Archived',
    );
    await TripService.saveTrip(archivedTrip);
    _showSnackBar('Trip to ${trip.location} archived', Colors.blue);
  }

  Future<void> _restoreTrip(firestoretrip.Trip trip) async {
    final restoredTrip = firestoretrip.Trip(
      id: trip.id,
      name: trip.name,
      location: trip.location,
      startDate: trip.startDate,
      endDate: trip.endDate,
      transportation: trip.transportation,
      spots: trip.spots,
      userId: trip.userId,
      status: 'Planning',
    );
    await TripService.saveTrip(restoredTrip);
    _showSnackBar('Trip to ${trip.location} restored', Colors.blue);
  }

  Future<void> _deleteTrip(String tripId) async {
    await TripService.deleteTrip(tripId);
    _showSnackBar('Trip deleted', Colors.red);
  }

  // UI helper methods
  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: _tripStream,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }
        final trips =
            snapshot.data?.docs
                .map((doc) {
                  final data = doc.data();
                  if (data is Map<String, dynamic>) {
                    return firestoretrip.Trip.fromMap(data);
                  }
                  return null;
                })
                .whereType<firestoretrip.Trip>()
                .toList() ??
            [];
        final myTrips = trips.where((t) => t.status != 'Archived').toList();
        final archivedTrips =
            trips.where((t) => t.status == 'Archived').toList();
        return DefaultTabController(
          length: 2,
          child: Scaffold(
            appBar: AppBar(
              title: const Text('My Trips'),
              bottom: TabBar(
                controller: _tabController,
                tabs: const [Tab(text: 'Active'), Tab(text: 'Archived')],
              ),
            ),
            body: TabBarView(
              controller: _tabController,
              children: [
                _buildTripList(myTrips, false),
                _buildTripList(archivedTrips, true),
              ],
            ),
            floatingActionButton: FloatingActionButton(
              onPressed: () async {
                final result = await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder:
                        (context) => const TripBasicInfoScreen(
                          destination: "New Destination",
                        ),
                  ),
                );
                if (result != null && result is Map<String, dynamic>) {
                  // Ensure id and userId are set
                  final trip = firestoretrip.Trip.fromMap(result);
                  _addNewTrip(trip);
                  if (_tabController.index != 0) {
                    _tabController.animateTo(0);
                  }
                }
              },
              child: const Icon(Icons.add),
            ),
          ),
        );
      },
    );
  }

  Widget _buildTripList(List<firestoretrip.Trip> trips, bool isArchived) {
    return ListView.builder(
      itemCount: trips.length,
      itemBuilder: (context, index) {
        final trip = trips[index];
        return ListTile(
          title: Text(trip.name),
          subtitle: Text(trip.location),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (!isArchived)
                IconButton(
                  icon: const Icon(Icons.archive),
                  onPressed: () => _archiveTrip(trip),
                ),
              if (isArchived)
                IconButton(
                  icon: const Icon(Icons.restore),
                  onPressed: () => _restoreTrip(trip),
                ),
              IconButton(
                icon: const Icon(Icons.delete),
                onPressed: () => _deleteTrip(trip.id),
              ),
            ],
          ),
        );
      },
    );
  }
}
