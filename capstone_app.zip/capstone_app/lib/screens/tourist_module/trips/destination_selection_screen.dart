// filepath: d:/Flutter_Projects/capstone_app/lib/screens/tourist_module.dart/trips/destination_selection_screen.dart

// ignore_for_file: depend_on_referenced_packages, deprecated_member_use

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:capstone_app/utils/colors.dart';
import 'package:capstone_app/models/place.dart';
import 'package:capstone_app/models/trip_model.dart';

/// Screen for selecting places to visit during a trip
class DestinationSelectionScreen extends StatefulWidget {
  final String destination;
  final String tripName;
  final DateTime startDate;
  final DateTime endDate;
  final String transportation;

  const DestinationSelectionScreen({
    super.key,
    required this.destination,
    required this.tripName,
    required this.startDate,
    required this.endDate,
    required this.transportation,
  });

  @override
  State<DestinationSelectionScreen> createState() =>
      _DestinationSelectionScreenState();
}

class _DestinationSelectionScreenState
    extends State<DestinationSelectionScreen> {
  // State variables
  late List<String> _popularPlaces;
  final List<PlaceVisit> _placesToVisit = [];
  final TextEditingController _placeController = TextEditingController();
  String? _currentlyEditingPlace;
  DateTime? _selectedPlaceDate;

  @override
  void initState() {
    super.initState();
    _loadPopularPlaces();
    _selectedPlaceDate = widget.startDate;
  }

  @override
  void dispose() {
    _placeController.dispose();
    super.dispose();
  }

  /// Loads popular places based on the destination
  void _loadPopularPlaces() {
    switch (widget.destination.toLowerCase()) {
      case 'baltimore':
        _popularPlaces = [
          'Inner Harbor',
          'National Aquarium',
          'Fort McHenry',
          'Camden Yards',
          'American Visionary Art Museum',
        ];
        break;
      case 'new york':
        _popularPlaces = [
          'Statue of Liberty',
          'Central Park',
          'Empire State Building',
          'Times Square',
          'Brooklyn Bridge',
        ];
        break;
      default:
        _popularPlaces = [
          'City Center',
          'Town Square',
          'Local Museum',
          'Historic District',
          'City Park',
        ];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          'Trip to ${widget.destination}',
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [_buildProgressIndicator(), Expanded(child: _buildContent())],
      ),
    );
  }

  /// Builds the progress indicator showing current step
  Widget _buildProgressIndicator() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 12.0),
      child: Row(
        children: List.generate(3, (index) {
          return Expanded(
            child: Container(
              height: 6,
              margin: const EdgeInsets.symmetric(horizontal: 4),
              decoration: BoxDecoration(
                color:
                    index < 3 - 1
                        ? AppColors.primaryOrange
                        : AppColors.textLight.withOpacity(0.2),
                borderRadius: BorderRadius.circular(3),
              ),
            ),
          );
        }),
      ),
    );
  }

  /// Builds the main content area
  Widget _buildContent() {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Select places to visit',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(
            'Add places from suggestions or create your own',
            style: const TextStyle(fontSize: 14, color: AppColors.textLight),
          ),
          const SizedBox(height: 16),
          _buildAddCustomPlace(),
          const SizedBox(height: 16),
          if (_placesToVisit.isNotEmpty) _buildItinerary(),
          Expanded(child: _buildPopularPlaces()),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              onPressed: _finishPlanning,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryOrange,
                foregroundColor: Colors.white,
              ),
              child: const Text('Finish'),
            ),
          ),
        ],
      ),
    );
  }

  /// Builds the custom place input section
  Widget _buildAddCustomPlace() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.backgroundColor,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.primaryOrange.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.add_location,
                color: AppColors.primaryOrange,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Add Custom Place',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                  color: AppColors.primaryOrange,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _placeController,
                  decoration: InputDecoration(
                    hintText: 'Enter place name...',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: Colors.grey.shade300),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                      borderSide: BorderSide(color: AppColors.primaryOrange),
                    ),
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 12,
                    ),
                  ),
                  onSubmitted: (value) => _addCustomPlace(),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton(
                onPressed: _addCustomPlace,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryOrange,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text('Add'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  /// Builds the itinerary section
  Widget _buildItinerary() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Your Itinerary',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
        ),
        const SizedBox(height: 8),
        Container(
          decoration: BoxDecoration(
            color: AppColors.backgroundColor,
            borderRadius: BorderRadius.circular(12),
          ),
          child: ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _placesToVisit.length,
            separatorBuilder: (context, index) => const Divider(height: 1),
            itemBuilder: (context, index) {
              final place = _placesToVisit[index];
              return ListTile(
                title: Text(place.place),
                subtitle: Text(DateFormat('MMM dd, yyyy').format(place.date)),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(
                        Icons.edit,
                        color: AppColors.primaryOrange,
                      ),
                      onPressed: () => _editPlace(place),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () => _deletePlace(index),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  /// Builds the popular places section
  Widget _buildPopularPlaces() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Popular Places in  24{widget.destination}',
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
        ),
        const SizedBox(height: 8),
        Expanded(
          child: ListView.builder(
            itemCount: _popularPlaces.length,
            itemBuilder: (context, index) {
              final place = _popularPlaces[index];
              final alreadyAdded = _placesToVisit.any((p) => p.place == place);
              return Card(
                color:
                    alreadyAdded
                        ? AppColors.primaryOrange.withOpacity(0.1)
                        : Colors.white,
                child: ListTile(
                  leading: Icon(
                    Icons.location_on,
                    color: AppColors.primaryOrange,
                  ),
                  title: Text(place),
                  trailing:
                      alreadyAdded
                          ? const Icon(
                            Icons.check,
                            color: AppColors.primaryOrange,
                          )
                          : IconButton(
                            icon: const Icon(
                              Icons.add,
                              color: AppColors.primaryOrange,
                            ),
                            onPressed: () => _addPlace(place),
                          ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  /// Adds a custom place from text input
  void _addCustomPlace() {
    final placeName = _placeController.text.trim();
    if (placeName.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter a place name'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    // Check if place already exists
    if (_placesToVisit.any(
      (p) => p.place.toLowerCase() == placeName.toLowerCase(),
    )) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('This place is already in your itinerary'),
          backgroundColor: Colors.orange,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    _placeController.clear();
    _addPlace(placeName);
  }

  /// Adds a place to the itinerary
  void _addPlace(String place) {
    _currentlyEditingPlace = place;
    _selectedPlaceDate = widget.startDate;
    _showDatePicker();
  }

  /// Edits an existing place
  void _editPlace(PlaceVisit placeVisit) {
    _currentlyEditingPlace = placeVisit.place;
    _selectedPlaceDate = placeVisit.date;
    _placesToVisit.removeWhere((p) => p.place == placeVisit.place);
    _showDatePicker();
  }

  /// Deletes a place from the itinerary
  void _deletePlace(int index) {
    setState(() {
      _placesToVisit.removeAt(index);
    });
  }

  /// Shows the date picker dialog
  void _showDatePicker() {
    int duration = widget.endDate.difference(widget.startDate).inDays + 1;
    List<DateTime> availableDates = List.generate(
      duration,
      (index) => widget.startDate.add(Duration(days: index)),
    );
    showDialog(
      context: context,
      builder:
          (context) => StatefulBuilder(
            builder: (context, setDialogState) {
              return AlertDialog(
                title: Text('Select date for $_currentlyEditingPlace'),
                content: SizedBox(
                  height: 200,
                  child: ListView.builder(
                    itemCount: availableDates.length,
                    itemBuilder: (context, index) {
                      final date = availableDates[index];
                      final isSelected = _selectedPlaceDate == date;
                      return ListTile(
                        title: Text(DateFormat('MMM dd, yyyy').format(date)),
                        trailing:
                            isSelected
                                ? const Icon(
                                  Icons.check,
                                  color: AppColors.primaryOrange,
                                )
                                : null,
                        onTap: () {
                          setDialogState(() {
                            _selectedPlaceDate = date;
                          });
                        },
                      );
                    },
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('Cancel'),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      _savePlaceWithDate();
                      Navigator.pop(context);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryOrange,
                      foregroundColor: Colors.white,
                    ),
                    child: const Text('Save'),
                  ),
                ],
              );
            },
          ),
    );
  }

  /// Saves the place with the selected date
  void _savePlaceWithDate() {
    if (_currentlyEditingPlace != null && _selectedPlaceDate != null) {
      setState(() {
        _placesToVisit.add(
          PlaceVisit(place: _currentlyEditingPlace!, date: _selectedPlaceDate!),
        );
        // Sort places by date
        _placesToVisit.sort((a, b) => a.date.compareTo(b.date));
      });
    }
  }

  /// Finishes the trip planning process
  void _finishPlanning() {
    if (_placesToVisit.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please add at least one place to visit'),
          backgroundColor: AppColors.primaryOrange,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    // Create Trip object with the selected places
    final trip = Trip(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: widget.tripName,
      location: widget.destination,
      startDate: widget.startDate,
      endDate: widget.endDate,
      transportation: widget.transportation,
      spots: _placesToVisit.map((p) => p.place).toList(),
      userId: '', // You'll need to get this from your auth system
    );

    final tripData = {
      'destination': widget.destination,
      'tripName': widget.tripName,
      'startDate': widget.startDate.toIso8601String(),
      'endDate': widget.endDate.toIso8601String(),
      'transportation': widget.transportation,
      'places':
          _placesToVisit
              .map((p) => {'place': p.place, 'date': p.date.toIso8601String()})
              .toList(),
      'trip': trip.toMap(),
    };

    Navigator.of(context).pop(tripData);
  }
}
