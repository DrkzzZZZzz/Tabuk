import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart' as geo;
import 'package:capstone_app/services/hotspot_service.dart';
import 'package:capstone_app/models/hotspots_model.dart';

// Constants for map configuration
const double kInitialZoom = 9.0;
const double kMinZoom = 8.0;
const double kMaxZoom = 18.0;
const double kLocationZoom = 15.0;
const Duration kLocationTimeout = Duration(seconds: 5);
const Duration kServiceCheckTimeout = Duration(seconds: 2);

// Custom map style to remove unnecessary POIs and transit lines
const String kMapStyle = '''[
  {
    "featureType": "poi",
    "elementType": "labels",
    "stylers": [{"visibility": "off"}]
  },
  {
    "featureType": "transit",
    "elementType": "labels",
    "stylers": [{"visibility": "off"}]
  },
  {
    "featureType": "transit.line",
    "elementType": "geometry",
    "stylers": [{"visibility": "off"}]
  }
]''';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  GoogleMapController? _mapController;
  MapType _currentMapType = MapType.normal;
  bool _isMapLoading = true;
  bool _locationPermissionGranted = false;
  bool _isCheckingLocation = false;
  Set<Marker> _hotspotMarkers = {};
  late Stream<List<Hotspot>> _hotspotsStream;

  // Bukidnon province bounds
  static const LatLng bukidnonCenter = LatLng(8.0515, 124.9230);
  static final LatLngBounds bukidnonBounds = LatLngBounds(
    southwest: LatLng(7.2500, 124.2500),
    northeast: LatLng(8.8500, 125.5833),
  );

  @override
  void initState() {
    super.initState();
    _checkLocationPermission();
    _hotspotsStream = HotspotService.getHotspotsStream();
    _hotspotsStream.listen((hotspots) {
      setState(() {
        _hotspotMarkers =
            hotspots
                .map(
                  (hotspot) => Marker(
                    markerId: MarkerId(hotspot.hotspotId),
                    position: LatLng(hotspot.latitude, hotspot.longitude),
                    onTap: () => _showHotspotDetailsSheet(hotspot),
                  ),
                )
                .toSet();
      });
    });
  }

  @override
  void dispose() {
    _mapController?.dispose();
    super.dispose();
  }

  Future<bool> _checkLocationService() async {
    try {
      final serviceEnabled = await geo.Geolocator.isLocationServiceEnabled()
          .timeout(kServiceCheckTimeout);

      if (!serviceEnabled && mounted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return AlertDialog(
              title: const Text('GPS is Disabled'),
              content: const Text(
                'Please enable GPS to use location features.',
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Cancel'),
                ),
                TextButton(
                  onPressed: () async {
                    Navigator.pop(context);
                    await geo.Geolocator.openLocationSettings();
                  },
                  child: const Text('Enable GPS'),
                ),
              ],
            );
          },
        );
      }
      return serviceEnabled;
    } catch (e) {
      debugPrint('Error checking location service: $e');
      return false;
    }
  }

  Future<void> _checkLocationPermission() async {
    try {
      var permission = await geo.Geolocator.checkPermission();
      if (permission == geo.LocationPermission.denied) {
        permission = await geo.Geolocator.requestPermission();
        if (permission == geo.LocationPermission.denied) {
          if (mounted) {
            setState(() => _locationPermissionGranted = false);
          }
          return;
        }
      }

      if (permission == geo.LocationPermission.deniedForever) {
        if (mounted) {
          setState(() => _locationPermissionGranted = false);
        }
        return;
      }

      if (mounted) {
        setState(() => _locationPermissionGranted = true);
      }
    } catch (e) {
      debugPrint('Error checking location permission: $e');
      if (mounted) {
        setState(() => _locationPermissionGranted = false);
      }
    }
  }

  void _onMapCreated(GoogleMapController controller) {
    setState(() {
      _mapController = controller;
      _mapController?.setMapStyle(kMapStyle);
      _isMapLoading = false;
    });
  }

  bool _isLocationInBukidnon(LatLng location) {
    return location.latitude >= bukidnonBounds.southwest.latitude &&
        location.latitude <= bukidnonBounds.northeast.latitude &&
        location.longitude >= bukidnonBounds.southwest.longitude &&
        location.longitude <= bukidnonBounds.northeast.longitude;
  }

  Future<void> _goToMyLocation() async {
    if (_isCheckingLocation) return;
    setState(() => _isCheckingLocation = true);

    try {
      // First check if GPS is enabled
      final serviceEnabled = await _checkLocationService();
      if (!serviceEnabled) {
        setState(() => _isCheckingLocation = false);
        return; // Early return if GPS is off, dialog already shown
      }

      // Then check permission
      if (!_locationPermissionGranted) {
        await _checkLocationPermission();
        if (!_locationPermissionGranted) {
          _showPermissionDeniedDialog();
          setState(() => _isCheckingLocation = false);
          return;
        }
      }

      // Get current position
      final position = await geo.Geolocator.getCurrentPosition(
        desiredAccuracy: geo.LocationAccuracy.high,
        timeLimit: kLocationTimeout,
      );

      if (!mounted) return;

      final userLocation = LatLng(position.latitude, position.longitude);

      if (!_isLocationInBukidnon(userLocation)) {
        _showLocationOutOfBoundsDialog();
        return;
      }

      await _mapController?.animateCamera(
        CameraUpdate.newCameraPosition(
          CameraPosition(target: userLocation, zoom: kLocationZoom),
        ),
      );
    } catch (e) {
      debugPrint('Error getting location: $e');
      if (mounted) {
        // Only show location error if GPS is on but we failed to get location
        if (await geo.Geolocator.isLocationServiceEnabled()) {
          _showLocationErrorDialog();
        }
      }
    } finally {
      if (mounted) {
        setState(() => _isCheckingLocation = false);
      }
    }
  }

  void _showPermissionDeniedDialog() {
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Location Permission Required'),
          content: const Text(
            'Please grant location permission in settings to use this feature.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                Navigator.pop(context);
                await geo.Geolocator.openAppSettings();
              },
              child: const Text('Open Settings'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _goToBukidnonCenter() async {
    await _mapController?.animateCamera(
      CameraUpdate.newCameraPosition(
        const CameraPosition(target: bukidnonCenter, zoom: kInitialZoom),
      ),
    );
  }

  void _showLocationOutOfBoundsDialog() {
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Location Outside Bukidnon'),
          content: const Text('Your location is outside the Bukidnon region.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _goToBukidnonCenter();
              },
              child: const Text('Go to Center'),
            ),
          ],
        );
      },
    );
  }

  void _showLocationErrorDialog() {
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Location Error'),
          content: const Text(
            'Unable to get your current location. Please try again.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  void _toggleMapType() {
    setState(() {
      _currentMapType =
          _currentMapType == MapType.normal
              ? MapType.satellite
              : MapType.normal;
    });
  }

  void _showHotspotDetailsSheet(Hotspot hotspot) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) {
        return Dialog(
          insetPadding: EdgeInsets.zero,
          backgroundColor: Colors.transparent,
          child: Align(
            alignment: Alignment.center,
            child: Container(
              constraints: BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width * 0.9,
                maxHeight: MediaQuery.of(context).size.height * 0.8,
              ),
              margin: EdgeInsets.zero,
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.all(Radius.circular(0)),
              ),
              child: Stack(
                children: [
                  SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Stack(
                          children: [
                            ClipRRect(
                              borderRadius: const BorderRadius.only(
                                topLeft: Radius.circular(0),
                                topRight: Radius.circular(0),
                              ),
                              child: AspectRatio(
                                aspectRatio: 16 / 9,
                                child:
                                    hotspot.images.isNotEmpty
                                        ? Image.network(
                                          hotspot.images.first,
                                          width: double.infinity,
                                          fit: BoxFit.cover,
                                        )
                                        : Container(color: Colors.grey[300]),
                              ),
                            ),
                          ],
                        ),
                        Padding(
                          padding: const EdgeInsets.all(20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                hotspot.name,
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 22,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                hotspot.description,
                                style: const TextStyle(
                                  fontSize: 14,
                                  color: Colors.black87,
                                ),
                              ),
                              const SizedBox(height: 8),
                              Row(
                                children: [
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: Colors.green.shade100,
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: const Text(
                                      'Open',
                                      style: TextStyle(
                                        color: Colors.green,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Text(
                                    hotspot.category,
                                    style: const TextStyle(
                                      fontSize: 13,
                                      color: Colors.grey,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Text(
                                'Transportation Available: ${hotspot.transportation.isNotEmpty ? hotspot.transportation.join(", ") : "Unknown"}',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                'Operating Hours: ${hotspot.operatingHours.isNotEmpty ? hotspot.operatingHours : "Unknown"}',
                              ),
                              Text(
                                'Safety Tips & Warnings: ${hotspot.safetyTips.isNotEmpty ? hotspot.safetyTips.join(", ") : "Unknown"}',
                              ),
                              Text(
                                'Entrance Fee: ${hotspot.entranceFee != null ? hotspot.entranceFee.toString() : "Unknown"}',
                              ),
                              Text(
                                'Contact Info: ${hotspot.contactInfo.isNotEmpty ? hotspot.contactInfo : "Unknown"}',
                              ),
                              Text(
                                'Local Guide: ${hotspot.localGuide.isNotEmpty ? hotspot.localGuide : "Unknown"}',
                              ),
                              Text(
                                'Restroom: ${hotspot.restroom ? "Available" : "Not Available"}',
                              ),
                              Text(
                                'Food Access: ${hotspot.foodAccess ? "Available" : "Not Available"}',
                              ),
                              Text(
                                'Suggested to Bring: ${hotspot.suggestions.isNotEmpty ? hotspot.suggestions.join(", ") : "Unknown"}',
                              ),
                              const SizedBox(height: 18),
                              Row(children: [const Spacer()]),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  // X button in the top right corner
                  Positioned(
                    top: 24,
                    right: 24,
                    child: Container(
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.5),
                        shape: BoxShape.circle,
                      ),
                      child: IconButton(
                        icon: const Icon(
                          Icons.close,
                          color: Colors.white,
                          size: 32,
                        ),
                        onPressed: () => Navigator.pop(context),
                        tooltip: 'Close',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    return Scaffold(
      body: Stack(
        children: [
          GoogleMap(
            onMapCreated: _onMapCreated,
            initialCameraPosition: const CameraPosition(
              target: bukidnonCenter,
              zoom: kInitialZoom,
            ),
            mapType: _currentMapType,
            myLocationEnabled: _locationPermissionGranted,
            myLocationButtonEnabled: false,
            compassEnabled: true,
            zoomGesturesEnabled: true,
            rotateGesturesEnabled: true,
            tiltGesturesEnabled: false,
            scrollGesturesEnabled: true,
            zoomControlsEnabled: false,
            minMaxZoomPreference: const MinMaxZoomPreference(
              kMinZoom,
              kMaxZoom,
            ),
            cameraTargetBounds: CameraTargetBounds(bukidnonBounds),
            padding: EdgeInsets.only(bottom: 80 + bottomPadding),
            markers: _hotspotMarkers,
          ),
          if (_isMapLoading)
            const ColoredBox(
              color: Colors.white,
              child: Center(child: CircularProgressIndicator()),
            ),
          Positioned(
            bottom: 16 + bottomPadding,
            right: 16,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                FloatingActionButton(
                  heroTag: "mapType",
                  mini: true,
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.black87,
                  elevation: 4,
                  onPressed: _toggleMapType,
                  child: const Icon(Icons.layers),
                ),
                const SizedBox(height: 8),
                FloatingActionButton(
                  heroTag: "location",
                  mini: true,
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.blue,
                  elevation: 4,
                  onPressed: _isCheckingLocation ? null : _goToMyLocation,
                  child:
                      _isCheckingLocation
                          ? const SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.blue,
                            ),
                          )
                          : const Icon(Icons.my_location),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
