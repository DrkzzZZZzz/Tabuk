import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:async';
import 'dart:math';

class MapScreenBetter extends StatefulWidget {
  const MapScreenBetter({super.key});

  @override
  State<MapScreenBetter> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreenBetter>
    with TickerProviderStateMixin {
  GoogleMapController? _mapController;
  MapType _currentMapType = MapType.normal;
  bool _isSearchExpanded = false;
  bool _showLocationInfo = false;
  String _currentLocationName = "Bukidnon Province";

  late AnimationController _pulseController;
  late AnimationController _slideController;
  late Animation<double> _pulseAnimation;
  late Animation<Offset> _slideAnimation;

  final TextEditingController _searchController = TextEditingController();
  final Set<Marker> _markers = {};
  final Set<Polyline> _polylines = {};
  final Set<Circle> _circles = {};

  // Bukidnon province bounds
  static const LatLng bukidnonCenter = LatLng(7.9, 125.0);
  static final LatLngBounds bukidnonBounds = LatLngBounds(
    southwest: LatLng(7.0, 124.0),
    northeast: LatLng(8.8, 125.8),
  );

  // Popular places in Bukidnon
  final List<Map<String, dynamic>> _popularPlaces = [
    {
      'name': 'Dahilayan Adventure Park',
      'position': LatLng(8.3, 125.0),
      'description': 'Famous zipline and adventure activities',
      'icon': Icons.sports_motorsports,
      'color': Colors.orange,
    },
    {
      'name': 'Monastery of Transfiguration',
      'position': LatLng(8.15, 125.13),
      'description': 'Beautiful monastery with unique architecture',
      'icon': Icons.church,
      'color': Colors.purple,
    },
    {
      'name': 'Kaamulan Grounds',
      'position': LatLng(8.13, 125.13),
      'description': 'Cultural festival grounds of Bukidnon',
      'icon': Icons.festival,
      'color': Colors.red,
    },
    {
      'name': 'Del Monte Pineapple Plantation',
      'position': LatLng(7.8, 125.2),
      'description': 'Vast pineapple plantation tours',
      'icon': Icons.agriculture,
      'color': Colors.green,
    },
    {
      'name': 'Pulangi River',
      'position': LatLng(7.7, 124.8),
      'description': 'Scenic river perfect for kayaking',
      'icon': Icons.water,
      'color': Colors.blue,
    },
  ];

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _addPopularPlaceMarkers();
    _startLocationUpdates();
  }

  void _initializeAnimations() {
    _pulseController = AnimationController(
      duration: const Duration(seconds: 2),
      vsync: this,
    )..repeat(reverse: true);

    _slideController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    _pulseAnimation = Tween<double>(begin: 0.8, end: 1.2).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, -1),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(parent: _slideController, curve: Curves.elasticOut),
    );
  }

  void _startLocationUpdates() {
    Timer.periodic(const Duration(seconds: 5), (timer) {
      if (mounted) {
        setState(() {
          _currentLocationName = _getRandomLocationName();
        });
      }
    });
  }

  String _getRandomLocationName() {
    final locations = [
      "Bukidnon Province",
      "Valencia City",
      "Malaybalay City",
      "Cagayan de Oro nearby",
      "Northern Mindanao",
    ];
    return locations[Random().nextInt(locations.length)];
  }

  void _addPopularPlaceMarkers() {
    _markers.clear();
    for (int i = 0; i < _popularPlaces.length; i++) {
      final place = _popularPlaces[i];
      _markers.add(
        Marker(
          markerId: MarkerId('place_$i'),
          position: place['position'],
          infoWindow: InfoWindow(
            title: place['name'],
            snippet: place['description'],
          ),
          icon: BitmapDescriptor.defaultMarkerWithHue(
            _getHueFromColor(place['color']),
          ),
          onTap: () => _showPlaceDetails(place),
        ),
      );
    }
  }

  double _getHueFromColor(Color color) {
    if (color == Colors.orange) return BitmapDescriptor.hueOrange;
    if (color == Colors.purple) return BitmapDescriptor.hueViolet;
    if (color == Colors.red) return BitmapDescriptor.hueRed;
    if (color == Colors.green) return BitmapDescriptor.hueGreen;
    if (color == Colors.blue) return BitmapDescriptor.hueBlue;
    return BitmapDescriptor.hueRed;
  }

  void _showPlaceDetails(Map<String, dynamic> place) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder:
          (context) => Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(place['icon'], color: place['color'], size: 30),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          place['name'],
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    place['description'],
                    style: const TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed:
                              () => _navigateToLocation(place['position']),
                          icon: const Icon(Icons.directions),
                          label: const Text('Navigate'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue,
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => _addToFavorites(place),
                          icon: const Icon(Icons.favorite_border),
                          label: const Text('Save'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
    );
  }

  void _navigateToLocation(LatLng position) {
    Navigator.pop(context);
    _mapController?.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(target: position, zoom: 15.0),
      ),
    );
    _addNavigationCircle(position);
  }

  void _addNavigationCircle(LatLng center) {
    setState(() {
      _circles.add(
        Circle(
          circleId: const CircleId('navigation'),
          center: center,
          radius: 500,
          fillColor: Colors.blue.withOpacity(0.2),
          strokeColor: Colors.blue,
          strokeWidth: 2,
        ),
      );
    });

    Timer(const Duration(seconds: 3), () {
      if (mounted) {
        setState(() {
          _circles.clear();
        });
      }
    });
  }

  void _addToFavorites(Map<String, dynamic> place) {
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${place['name']} added to favorites!'),
        backgroundColor: Colors.green,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  void _onMapCreated(GoogleMapController controller) {
    _mapController = controller;
    _slideController.forward();

    controller.setMapStyle('''
    [
      {
        "featureType": "administrative",
        "elementType": "geometry.stroke",
        "stylers": [{"visibility": "on", "color": "#4285f4"}]
      },
      {
        "featureType": "water",
        "elementType": "geometry.fill",
        "stylers": [{"color": "#4fc3f7"}]
      }
    ]
    ''');
  }

  Future<void> _goToBukidnonCenter() async {
    if (_mapController != null) {
      await _mapController!.animateCamera(
        CameraUpdate.newCameraPosition(
          const CameraPosition(target: bukidnonCenter, zoom: 9.0),
        ),
      );
      _showLocationPulse();
    }
  }

  void _showLocationPulse() {
    setState(() {
      _showLocationInfo = true;
    });
    Timer(const Duration(seconds: 2), () {
      if (mounted) {
        setState(() {
          _showLocationInfo = false;
        });
      }
    });
  }

  void _toggleSearch() {
    setState(() {
      _isSearchExpanded = !_isSearchExpanded;
    });
    if (_isSearchExpanded) {
      _slideController.forward();
    } else {
      _slideController.reverse();
      _searchController.clear();
    }
  }

  void _performSearch(String query) {
    if (query.isEmpty) return;

    final matchingPlaces =
        _popularPlaces
            .where(
              (place) =>
                  place['name'].toLowerCase().contains(query.toLowerCase()),
            )
            .toList();

    if (matchingPlaces.isNotEmpty) {
      _navigateToLocation(matchingPlaces.first['position']);
      _toggleSearch();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Location not found. Try searching for popular places!',
          ),
          backgroundColor: Colors.orange,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Google Maps
          GoogleMap(
            onMapCreated: _onMapCreated,
            initialCameraPosition: const CameraPosition(
              target: bukidnonCenter,
              zoom: 9.0,
            ),
            mapType: _currentMapType,
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            compassEnabled: true,
            tiltGesturesEnabled: true,
            scrollGesturesEnabled: true,
            zoomGesturesEnabled: true,
            rotateGesturesEnabled: true,
            minMaxZoomPreference: const MinMaxZoomPreference(8.0, 18.0),
            cameraTargetBounds: CameraTargetBounds(bukidnonBounds),
            markers: _markers,
            polylines: _polylines,
            circles: _circles,
            onTap: (LatLng position) {
              // Add temporary marker on tap
              setState(() {
                _markers.add(
                  Marker(
                    markerId: const MarkerId('temp'),
                    position: position,
                    infoWindow: const InfoWindow(title: 'Tapped Location'),
                    alpha: 0.7,
                  ),
                );
              });
              Timer(const Duration(seconds: 2), () {
                setState(() {
                  _markers.removeWhere(
                    (marker) => marker.markerId.value == 'temp',
                  );
                });
              });
            },
          ),

          // Animated Top App Bar
          SlideTransition(
            position: _slideAnimation,
            child: Positioned(
              top: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: EdgeInsets.only(
                  top: MediaQuery.of(context).padding.top,
                  left: 16,
                  right: 16,
                  bottom: 8,
                ),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.blue.shade400, Colors.blue.shade600],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: _buildTopBar(),
              ),
            ),
          ),

          // Location Info Card
          if (_showLocationInfo)
            AnimatedBuilder(
              animation: _pulseAnimation,
              builder: (context, child) {
                return Positioned(
                  top: MediaQuery.of(context).padding.top + 80,
                  left: 16,
                  right: 16,
                  child: Transform.scale(
                    scale: _pulseAnimation.value,
                    child: Card(
                      elevation: 8,
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.location_on,
                              color: Colors.blue,
                              size: 30,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Text(
                                    'Your Current Area',
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                  Text(
                                    _currentLocationName,
                                    style: const TextStyle(
                                      color: Colors.grey,
                                      fontSize: 14,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),

          // Popular Places Quick Access
          Positioned(
            bottom: 200,
            left: 16,
            child: Column(
              children: [
                FloatingActionButton(
                  heroTag: "places",
                  mini: true,
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  elevation: 6,
                  onPressed: _showPopularPlaces,
                  child: const Icon(Icons.place),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Places',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                    shadows: [
                      Shadow(
                        blurRadius: 10.0,
                        color: Colors.black,
                        offset: Offset(1.0, 1.0),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Enhanced Control Buttons
          Positioned(
            bottom: 100,
            right: 16,
            child: Column(
              children: [
                FloatingActionButton(
                  heroTag: "location",
                  mini: true,
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.blue,
                  elevation: 6,
                  onPressed: _goToBukidnonCenter,
                  child: const Icon(Icons.my_location),
                ),
                const SizedBox(height: 12),
                FloatingActionButton(
                  heroTag: "layers",
                  mini: true,
                  backgroundColor: Colors.white,
                  foregroundColor: Colors.black87,
                  elevation: 6,
                  onPressed: _showMapTypeDialog,
                  child: const Icon(Icons.layers),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopBar() {
    return Row(
      children: [
        IconButton(
          icon: const Icon(Icons.menu, color: Colors.white),
          onPressed: () {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Menu feature coming soon!'),
                behavior: SnackBarBehavior.floating,
              ),
            );
          },
        ),
        Expanded(
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            height: 36,
            margin: const EdgeInsets.symmetric(horizontal: 8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 4),
              ],
            ),
            child:
                _isSearchExpanded
                    ? TextField(
                      controller: _searchController,
                      autofocus: true,
                      decoration: const InputDecoration(
                        hintText: 'Search places in Bukidnon...',
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                      ),
                      onSubmitted: _performSearch,
                    )
                    : GestureDetector(
                      onTap: _toggleSearch,
                      child: const Row(
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: 12),
                            child: Icon(
                              Icons.search,
                              color: Colors.grey,
                              size: 20,
                            ),
                          ),
                          Expanded(
                            child: Padding(
                              padding: EdgeInsets.only(left: 8),
                              child: Text(
                                'Search amazing places...',
                                style: TextStyle(
                                  color: Colors.grey,
                                  fontSize: 16,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
          ),
        ),
        TextButton(
          onPressed: _isSearchExpanded ? _toggleSearch : null,
          child: Text(
            _isSearchExpanded ? 'Cancel' : 'Explore',
            style: const TextStyle(color: Colors.white, fontSize: 16),
          ),
        ),
      ],
    );
  }

  void _showPopularPlaces() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder:
          (context) => DraggableScrollableSheet(
            initialChildSize: 0.6,
            maxChildSize: 0.9,
            minChildSize: 0.3,
            builder:
                (context, scrollController) => Container(
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(20),
                    ),
                  ),
                  child: Column(
                    children: [
                      Container(
                        width: 40,
                        height: 4,
                        margin: const EdgeInsets.symmetric(vertical: 10),
                        decoration: BoxDecoration(
                          color: Colors.grey[300],
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      const Padding(
                        padding: EdgeInsets.all(16),
                        child: Text(
                          'Popular Places in Bukidnon',
                          style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Expanded(
                        child: ListView.builder(
                          controller: scrollController,
                          itemCount: _popularPlaces.length,
                          itemBuilder: (context, index) {
                            final place = _popularPlaces[index];
                            return Card(
                              margin: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 4,
                              ),
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: place['color'],
                                  child: Icon(
                                    place['icon'],
                                    color: Colors.white,
                                  ),
                                ),
                                title: Text(place['name']),
                                subtitle: Text(place['description']),
                                trailing: const Icon(
                                  Icons.arrow_forward_ios,
                                  size: 16,
                                ),
                                onTap: () {
                                  Navigator.pop(context);
                                  _showPlaceDetails(place);
                                },
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
          ),
    );
  }

  void _showMapTypeDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          title: const Text('Choose Map Style'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildMapTypeOption(MapType.normal, Icons.map, 'Normal'),
              _buildMapTypeOption(
                MapType.satellite,
                Icons.satellite,
                'Satellite',
              ),
              _buildMapTypeOption(MapType.terrain, Icons.terrain, 'Terrain'),
              _buildMapTypeOption(
                MapType.hybrid,
                Icons.layers_outlined,
                'Hybrid',
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildMapTypeOption(MapType mapType, IconData icon, String title) {
    return Card(
      elevation: _currentMapType == mapType ? 4 : 0,
      color: _currentMapType == mapType ? Colors.blue.shade50 : null,
      child: ListTile(
        leading: Icon(
          icon,
          color: _currentMapType == mapType ? Colors.blue : null,
        ),
        title: Text(title),
        trailing:
            _currentMapType == mapType
                ? const Icon(Icons.check, color: Colors.blue)
                : null,
        onTap: () {
          setState(() {
            _currentMapType = mapType;
          });
          Navigator.pop(context);
        },
      ),
    );
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _slideController.dispose();
    _searchController.dispose();
    super.dispose();
  }
}
