// ignore_for_file: deprecated_member_use, use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:capstone_app/utils/constants.dart';
import 'package:capstone_app/utils/colors.dart';
import 'package:capstone_app/widgets/custom_text_field.dart';
import 'package:capstone_app/widgets/social_login_button.dart';
import 'package:capstone_app/screens/sign_up_screen.dart';
import 'package:capstone_app/widgets/custom_button.dart';
import 'package:capstone_app/services/auth_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:capstone_app/services/andriod_web_connectivity_service.dart';
import 'package:capstone_app/utils/navigation_helper.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  bool _isPasswordVisible = false;
  bool _isLoading = false;
  String? _emailError;
  String? _passwordError;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  String? _validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Email is required';
    }
    final emailRegex = RegExp(
      r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$',
    );
    if (!emailRegex.hasMatch(value)) {
      return 'Please enter a valid email address';
    }
    return null;
  }

  String? _validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Password is required';
    }
    if (value.length < 6) {
      return 'Password must be at least 6 characters long';
    }
    return null;
  }

  void _showRoleSelectionDialog({required Function(String) onRoleSelected}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        String selectedRole =
            AppConstants.hotspotCategories.contains('Tourist')
                ? 'Tourist'
                : AppConstants.role;
        return AlertDialog(
          backgroundColor: AppColors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Text(
            AppConstants.role,
            style: const TextStyle(
              color: AppColors.textDark,
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
          content: StatefulBuilder(
            builder: (context, setState) {
              return DropdownButtonFormField<String>(
                value: selectedRole,
                decoration: InputDecoration(
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.8),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: Colors.grey.withOpacity(0.3)),
                  ),
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 12,
                  ),
                ),
                items:
                    ['Business Owner', 'Tourist', 'Administrator']
                        .map(
                          (role) => DropdownMenuItem<String>(
                            value: role,
                            child: Text(
                              role,
                              style: const TextStyle(
                                color: AppColors.textDark,
                                fontSize: 14,
                              ),
                            ),
                          ),
                        )
                        .toList(),
                onChanged: (value) {
                  if (value != null) {
                    setState(() {
                      selectedRole = value;
                    });
                  }
                },
              );
            },
          ),
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                backgroundColor: AppColors.primaryTeal,
                foregroundColor: AppColors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 24,
                  vertical: 10,
                ),
              ),
              onPressed: () {
                Navigator.of(context).pop();
                onRoleSelected(selectedRole);
              },
              child: const Text(
                'Continue',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ),
          ],
        );
      },
    );
  }

  void _handleGoogleSignIn() async {
    if (!await _checkInternetConnection()) {
      _showSnackBar(
        'No internet connection. Please connect to the internet and try again.',
        Colors.red,
      );
      return;
    }
    setState(() {
      _isLoading = true;
    });
    try {
      // Always sign out from Google to force account picker
      await GoogleSignIn().signOut();
      final userCredential = await AuthService.signInWithGoogle();
      if (!mounted) return;
      if (userCredential != null) {
        // Check if user already has a role in Firestore
        final userDoc =
            await FirebaseFirestore.instance
                .collection('users')
                .doc(userCredential.user!.uid)
                .get();
        final existingRole = userDoc.data()?['role'];
        if (existingRole != null && existingRole.toString().isNotEmpty) {
          _showSnackBar('Google sign-in successful!', Colors.green);
          NavigationHelper.navigateBasedOnRole(context, existingRole);
        } else {
          // No role set, show dialog
          _showRoleSelectionDialog(
            onRoleSelected: (selectedRole) {
              AuthService.storeUserData(
                userCredential.user!.uid,
                userCredential.user!.email ?? '',
                selectedRole,
              ).then((_) {
                _showSnackBar('Role set successfully!', Colors.green);
                NavigationHelper.navigateBasedOnRole(context, selectedRole);
              });
            },
          );
        }
      } else {
        _showSnackBar('Google sign-in cancelled.', Colors.orange);
      }
    } catch (e) {
      if (!mounted) return;
      _showSnackBar(e.toString(), Colors.red);
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _handleEmailLogin() async {
    if (!await _checkInternetConnection()) {
      _showSnackBar(
        'No internet connection. Please connect to the internet and try again.',
        Colors.red,
      );
      return;
    }
    setState(() {
      _emailError = _validateEmail(_emailController.text);
      _passwordError = _validatePassword(_passwordController.text);
    });

    if (_emailError != null || _passwordError != null) return;

    setState(() {
      _isLoading = true;
    });

    try {
      final userCredential = await AuthService.signInWithEmailPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text,
      );
      if (!mounted) return;
      if (userCredential != null) {
        await AuthService.reloadUser();
        // Always enforce email verification before allowing access
        if (!AuthService.isEmailVerified) {
          await AuthService.signOut();
          _showEmailVerificationDialog();
          return;
        }

        // Fetch user role from Firestore
        final userDoc =
            await FirebaseFirestore.instance
                .collection('users')
                .doc(userCredential.user!.uid)
                .get();
        final existingRole = userDoc.data()?['role'];

        if (existingRole != null && existingRole.toString().isNotEmpty) {
          _showSnackBar('Login successful!', Colors.green);
          NavigationHelper.navigateBasedOnRole(context, existingRole);
        } else {
          // No role set, show dialog
          _showRoleSelectionDialog(
            onRoleSelected: (selectedRole) {
              NavigationHelper.navigateBasedOnRole(context, selectedRole);
            },
          );
        }
      }
    } catch (e) {
      if (!mounted) return;
      _showSnackBar(e.toString(), Colors.red);
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showEmailVerificationDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            AppConstants.emailNotVerifiedTitle,
            style: const TextStyle(
              color: AppColors.textDark,
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
          content: Text(
            AppConstants.emailNotVerifiedContent,
            style: const TextStyle(color: AppColors.textLight, fontSize: 14),
          ),
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                backgroundColor: AppColors.primaryTeal,
                foregroundColor: AppColors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
              ),
              onPressed: () async {
                Navigator.of(context).pop();
                await AuthService.signOut(); // Sign out user after dialog
              },
              child: Text(
                AppConstants.cancelButton,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
            TextButton(
              style: TextButton.styleFrom(
                backgroundColor: AppColors.primaryOrange,
                foregroundColor: AppColors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
              ),
              onPressed: () async {
                Navigator.of(context).pop();
                try {
                  await AuthService.sendEmailVerification();
                  await AuthService.signOut(); // Sign out user after resending
                  if (mounted) {
                    _showSnackBar(
                      AppConstants.verificationEmailResent,
                      AppColors.primaryTeal,
                    );
                  }
                } catch (e) {
                  if (mounted) {
                    _showSnackBar(e.toString(), Colors.red);
                  }
                }
              },
              child: Text(
                AppConstants.resendEmailButton,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  void _handleSignUpNavigation() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const SignUpScreen()),
    );
  }

  void _togglePasswordVisibility() {
    setState(() {
      _isPasswordVisible = !_isPasswordVisible;
    });
  }

  void _clearEmailError() {
    if (_emailError != null) {
      setState(() {
        _emailError = null;
      });
    }
  }

  void _clearPasswordError() {
    if (_passwordError != null) {
      setState(() {
        _passwordError = null;
      });
    }
  }

  void _showSnackBar(String message, Color backgroundColor) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: backgroundColor,
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Widget _buildLogo() {
    return SizedBox(
      width: 250,
      height: 250,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Image.asset(
          'assets/images/TABUK-new-logo.png',
          width: 250,
          height: 250,
          fit: BoxFit.contain,
          errorBuilder: (context, error, stackTrace) => _buildFallbackLogo(),
        ),
      ),
    );
  }

  Widget _buildFallbackLogo() {
    return Container(
      width: 250,
      height: 250,
      decoration: BoxDecoration(
        color: AppColors.primaryOrange,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha((0.1 * 255).toInt()),
            spreadRadius: 1,
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Stack(
        alignment: Alignment.center,
        children: [
          const Icon(Icons.landscape, size: 60, color: AppColors.primaryTeal),
          Positioned(
            bottom: 20,
            child: Text(
              AppConstants.appName,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: AppColors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _handleGuestLogin() async {
    if (!await _checkInternetConnection()) {
      _showSnackBar(
        'No internet connection. Please connect to the internet and try again.',
        Colors.red,
      );
      return;
    }
    setState(() {
      _isLoading = true;
    });
    try {
      final userCredential = await AuthService.signInAnonymously();
      if (!mounted) return;
      if (userCredential != null) {
        _showSnackBar('Signed in as guest.', Colors.green);
        // Use NavigationHelper to navigate to tourist module
        NavigationHelper.navigateBasedOnRole(context, 'guest');
      }
    } catch (e) {
      if (!mounted) return;
      _showSnackBar(e.toString(), Colors.red);
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Widget _buildSocialLoginButtons() {
    return Column(
      children: [
        SocialLoginButton(
          text: AppConstants.signInWithGoogle,
          imagePath: 'assets/images/icons8-google-48.png',
          backgroundColor: AppColors.white,
          textColor: AppColors.textDark,
          onPressed: kIsWeb ? _handleGoogleSignInWeb : _handleGoogleSignIn,
        ),
        const SizedBox(height: 12),
        SocialLoginButton(
          text: 'Continue as Guest',
          imagePath: '', // No icon for guest
          backgroundColor: AppColors.primaryTeal,
          textColor: AppColors.white,
          onPressed: _handleGuestLogin,
        ),
      ],
    );
  }

  // Web-specific Google sign-in handler
  void _handleGoogleSignInWeb() async {
    if (!await _checkInternetConnection()) {
      _showSnackBar(
        'No internet connection. Please connect to the internet and try again.',
        Colors.red,
      );
      return;
    }
    setState(() {
      _isLoading = true;
    });
    try {
      // Use the standard Google sign-in popup
      await GoogleSignIn().signOut(); // Always sign out to force account picker
      final user = await GoogleSignIn().signIn();
      if (user == null) {
        _showSnackBar('Google sign-in cancelled.', Colors.orange);
        return;
      }
      // Try to get the Firebase user
      final currentUser = AuthService.currentUser;
      if (currentUser == null) {
        _showSnackBar(
          'No Firebase user found after Google sign-in.',
          Colors.red,
        );
        return;
      }
      // Check if user already has a role in Firestore
      final userDoc =
          await FirebaseFirestore.instance
              .collection('users')
              .doc(currentUser.uid)
              .get();
      final existingRole = userDoc.data()?['role'];
      if (existingRole != null && existingRole.toString().isNotEmpty) {
        _showSnackBar('Google sign-in successful!', Colors.green);
        NavigationHelper.navigateBasedOnRole(context, existingRole);
      } else {
        // No role set, show dialog
        _showRoleSelectionDialog(
          onRoleSelected: (selectedRole) {
            AuthService.storeUserData(
              currentUser.uid,
              currentUser.email ?? '',
              selectedRole,
            ).then((_) {
              _showSnackBar('Role set successfully!', Colors.green);
              NavigationHelper.navigateBasedOnRole(context, selectedRole);
            });
          },
        );
      }
    } catch (e) {
      _showSnackBar(e.toString(), Colors.red);
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Widget _buildEmailField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomTextField(
          controller: _emailController,
          hintText: AppConstants.email,
          keyboardType: TextInputType.emailAddress,
          onChanged: (_) {
            _clearEmailError();
            return;
          },
          suffixIcon: null, // No icon for email field
        ),
        if (_emailError != null) ...[
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.only(left: 12),
            child: Text(
              _emailError!,
              style: const TextStyle(
                color: Colors.red,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ],
    );
  }

  Widget _buildPasswordField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomTextField(
          controller: _passwordController,
          hintText: AppConstants.password,
          obscureText: !_isPasswordVisible,
          onChanged: (_) {
            _clearPasswordError();
            return;
          },
          suffixIcon: IconButton(
            icon: Icon(
              _isPasswordVisible ? Icons.visibility_off : Icons.visibility,
              color: AppColors.textLight,
              size: 30,
            ),
            onPressed: _togglePasswordVisibility,
          ),
        ),
        if (_passwordError != null) ...[
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.only(left: 12),
            child: Text(
              _passwordError!,
              style: const TextStyle(
                color: Colors.red,
                fontSize: 12,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
        Align(
          alignment: Alignment.centerRight,
          child: TextButton(
            onPressed: _showForgotPasswordDialog,
            style: TextButton.styleFrom(
              foregroundColor: AppColors.primaryTeal,
              textStyle: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 13,
              ),
            ),
            child: Text(AppConstants.forgotPassword),
          ),
        ),
      ],
    );
  }

  Widget _buildLoginButton() {
    return CustomButton(
      text: _isLoading ? 'Signing In...' : AppConstants.loginWithEmail,
      onPressed: _isLoading ? () {} : _handleEmailLogin,
    );
  }

  Widget _buildSignUpPrompt() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          AppConstants.dontHaveAccount,
          style: const TextStyle(color: AppColors.textLight, fontSize: 12),
        ),
        const SizedBox(width: 4),
        GestureDetector(
          onTap: _handleSignUpNavigation,
          child: Text(
            AppConstants.signUp,
            style: const TextStyle(
              color: Color.fromARGB(255, 66, 151, 255),
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: Container(
        decoration: const BoxDecoration(gradient: AppColors.backgroundGradient),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24.0),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Flexible(flex: 2, child: Center(child: _buildLogo())),
                  _buildSocialLoginButtons(),
                  const SizedBox(height: 32),
                  _buildEmailField(),
                  const SizedBox(height: 16),
                  _buildPasswordField(),
                  const SizedBox(height: 32),
                  _buildLoginButton(),
                  Flexible(
                    flex: 1,
                    child: Container(
                      alignment: Alignment.bottomCenter,
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 32),
                        child: _buildSignUpPrompt(),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _showForgotPasswordDialog() {
    final email = _emailController.text.trim();
    showDialog(
      context: context,
      builder: (context) {
        final TextEditingController dialogEmailController =
            TextEditingController(text: email);
        return AlertDialog(
          title: Text(
            AppConstants.forgotPassword,
            style: const TextStyle(
              color: AppColors.textDark,
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
          content: TextField(
            controller: dialogEmailController,
            decoration: InputDecoration(
              labelText: AppConstants.email,
              border: const OutlineInputBorder(),
            ),
            keyboardType: TextInputType.emailAddress,
          ),
          actions: [
            TextButton(
              style: TextButton.styleFrom(
                backgroundColor: AppColors.primaryTeal,
                foregroundColor: AppColors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
              ),
              onPressed: () => Navigator.of(context).pop(),
              child: Text(
                AppConstants.cancelButton,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
            TextButton(
              style: TextButton.styleFrom(
                backgroundColor: AppColors.primaryOrange,
                foregroundColor: AppColors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 8,
                ),
              ),
              onPressed: () async {
                final enteredEmail = dialogEmailController.text.trim();
                if (enteredEmail.isEmpty) {
                  _showSnackBar('Please enter your email address.', Colors.red);
                  return;
                }
                try {
                  await AuthService.sendPasswordResetEmail(enteredEmail);
                  if (mounted) {
                    Navigator.of(context).pop();
                    _showSnackBar(
                      'Password reset email sent. Please check your inbox.',
                      AppColors.primaryTeal,
                    );
                  }
                } catch (e) {
                  if (mounted) {
                    _showSnackBar(e.toString(), Colors.red);
                  }
                }
              },
              child: Text(
                'Send Reset Link',
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Future<bool> _checkInternetConnection() async {
    return WebConnectivityService.isOnline();
  }
}
