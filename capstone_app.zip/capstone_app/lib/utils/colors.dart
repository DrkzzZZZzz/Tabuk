// ===========================================
// lib/constants/app_colors.dart
// ===========================================

import 'package:flutter/material.dart';

class AppColors {
  static const Color gradientStart = Color(0xFFFFF3CF);
  static const Color gradientEnd = Colors.white;

  // Original colors for compatibility
  static const Color primaryOrange = Color(0xFFFF8C42);
  static const Color primaryTeal = Color(0xFF2E8B8B);
  static const Color backgroundColor = Color(0xFFF5F5DC);
  static const Color textDark = Color(0xFF333333);
  static const Color textLight = Color(0xFF666666);
  static const Color white = Color(0xFFFFFFFF);
  static const Color googleBlue = Color(0xFF4285F4);
  static const Color facebookBlue = Color(0xFF1877F2);

  // Gradient background
  static const LinearGradient backgroundGradient = LinearGradient(
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
    colors: [gradientStart, gradientEnd],
    stops: [0.0, 1.0],
  );
}
