// ===========================================
// lib/utils/constants.dart
// ===========================================

class AppConstants {
  // App General
  static const String appName = 'TABUK';

  // admin constants
  static const String profile = 'Profile';
  static const String profileScreenPlaceholder = 'Profile Screen Placeholder';
  static const String signOut = 'Sign Out';

  // Authentication
  static const String signInWithGoogle = 'Sign up with Google';
  static const String loginWithEmail = 'Login with email';
  static const String email = 'Email';
  static const String password = 'Password';
  static const String dontHaveAccount = "Haven't have an account? ";
  static const String signUp = 'Create here';
  static const String confirmPassword = 'Confirm Password';
  static const String role = 'Role:';
  static const String signUpWithEmail = 'Sign up with email';
  static const String alreadyHaveAccount = 'Already have an account? ';
  static const String signIn = 'Sign In';
  static const String emailNotVerifiedTitle = 'Email Not Verified';
  static const String emailNotVerifiedContent =
      'Your email address is not verified. Please check your inbox for a verification email. If you did not receive it, you can resend the verification email.';
  static const String cancelButton = 'Cancel';
  static const String resendEmailButton = 'Resend Email';
  static const String verificationEmailResent =
      'Verification email resent. Please check your inbox.';
  static const String forgotPassword = 'Forgot Password?';

  // Events
  static const String eventCalendarTitle = 'Event Calendar';
  static const String thisMonth = 'This Month';
  static const String nextMonth = 'Next Month';
  static const String noEvents = 'No events';
  static const String events = 'Events';

  // Hotspots - Categories
  static const String naturalAttraction = 'Natural Attraction';
  static const String culturalSite = 'Cultural Site';
  static const String adventureSpot = 'Adventure Spot';
  static const String restaurant = 'Restaurant';
  static const String accommodation = 'Accommodation';
  static const String shopping = 'Shopping';
  static const String entertainment = 'Entertainment';

  static const List<String> hotspotCategories = [
    naturalAttraction,
    culturalSite,
    adventureSpot,
    restaurant,
    accommodation,
    shopping,
    entertainment,
  ];

  // Hotspots - Transportation
  static const String jeepney = 'Jeepney';
  static const String tricycle = 'Tricycle';
  static const String bus = 'Bus';
  static const String privateCar = 'Private Car';
  static const String motorcycle = 'Motorcycle';
  static const String walking = 'Walking';

  static const List<String> transportationOptions = [
    jeepney,
    tricycle,
    bus,
    privateCar,
    motorcycle,
    walking,
  ];

  // Hotspots - UI Text
  static const String hotspots = 'Hotspots';
  static const String hotspotDetails = 'Hotspot Details';
  static const String viewOnMap = 'View on Map';
  static const String getDirections = 'Get Directions';
  static const String shareHotspot = 'Share Hotspot';
  static const String addToFavorites = 'Add to Favorites';
  static const String removeFromFavorites = 'Remove from Favorites';
  static const String writeReview = 'Write Review';
  static const String seeAllReviews = 'See All Reviews';
  static const String operatingHours = 'Operating Hours';
  static const String entranceFee = 'Entrance Fee';
  static const String transportation = 'Transportation';
  static const String safetyTips = 'Safety Tips';
  static const String suggestions = 'Suggestions';
  static const String facilities = 'Facilities';
  static const String contactInfo = 'Contact Information';
  static const String localGuide = 'Local Guide';
  static const String restroom = 'Restroom Available';
  static const String foodAccess = 'Food Access';
  static const String noImageAvailable = 'No Image Available';
  static const String loadingHotspots = 'Loading hotspots...';
  static const String noHotspotsFound = 'No hotspots found';
  static const String errorLoadingHotspots = 'Error loading hotspots';
  static const String searchHotspots = 'Search hotspots...';
  static const String filterBy = 'Filter by';
  static const String sortBy = 'Sort by';
  static const String allCategories = 'All Categories';
  static const String nearbyHotspots = 'Nearby Hotspots';
  static const String popularHotspots = 'Popular Hotspots';
  static const String recentlyAdded = 'Recently Added';
  static const String featured = 'Featured';
  static const String free = 'Free';
  static const String paid = 'Paid';

  // Hotspots - Messages
  static const String hotspotAddedToFavorites = 'Hotspot added to favorites';
  static const String hotspotRemovedFromFavorites =
      'Hotspot removed from favorites';
  static const String failedToLoadHotspot = 'Failed to load hotspot details';
  static const String failedToAddFavorite = 'Failed to add to favorites';
  static const String failedToRemoveFavorite =
      'Failed to remove from favorites';

  // Common UI
  static const String retry = 'Retry';
  static const String refresh = 'Refresh';
  static const String loading = 'Loading...';
  static const String error = 'Error';
  static const String success = 'Success';
  static const String warning = 'Warning';
  static const String info = 'Info';
  static const String ok = 'OK';
  static const String yes = 'Yes';
  static const String no = 'No';
  static const String save = 'Save';
  static const String edit = 'Edit';
  static const String delete = 'Delete';
  static const String search = 'Search';
  static const String filter = 'Filter';
  static const String sort = 'Sort';
  static const String share = 'Share';
  static const String close = 'Close';
}
